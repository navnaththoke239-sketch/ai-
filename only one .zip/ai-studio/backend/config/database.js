import mongoose from 'mongoose';

export const connectDB = async () => {
  try {
    const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/ai-studio';
    const conn = await mongoose.connect(uri);
    console.log(`[DB] MongoDB connected: ${conn.connection.host}/${conn.connection.name}`);
  } catch (err) {
    console.error('[DB] MongoDB connection error:', err.message);
    // Don't crash the server on boot if DB is down; allow health check to report it.
    // Exit only in production after retries.
    if (process.env.NODE_ENV === 'production') {
      setTimeout(() => process.exit(1), 5000);
    }
  }
};

mongoose.connection.on('disconnected', () => console.warn('[DB] MongoDB disconnected'));
mongoose.connection.on('reconnected', () => console.log('[DB] MongoDB reconnected'));
