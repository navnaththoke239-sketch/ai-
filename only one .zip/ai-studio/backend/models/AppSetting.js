import mongoose from 'mongoose';

// App settings & provider config (editable from admin panel)
const settingsSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: mongoose.Schema.Types.Mixed, default: null },
  updatedAt: { type: Date, default: Date.now },
});

export default mongoose.model('AppSetting', settingsSchema);
