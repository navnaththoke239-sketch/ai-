package com.aistudio.data

import kotlinx.serialization.Serializable

// ---- Auth ----
@Serializable data class AuthRequest(val name: String? = null, val email: String, val password: String, val language: String? = null)
@Serializable data class AuthResponse(val token: String, val user: UserProfile)
@Serializable data class UserProfile(val id: String, val name: String, val email: String, val credits: Int, val isAdmin: Boolean = false, val language: String = "en", val avatarUrl: String? = null)

// ---- Chat ----
@Serializable data class ChatMessage(val role: String, val content: String, val language: String = "en", val timestamp: String? = null)
@Serializable data class ChatListItem(val id: String, val title: String, val updatedAt: String, val createdAt: String, val messageCount: Int = 0)
@Serializable data class ChatListResponse(val chats: List<ChatListItem>, val credits: Int)
@Serializable data class ChatSendRequest(val chatId: String? = null, val messages: List<ChatMessage>, val language: String = "en", val projectId: String? = null)
@Serializable data class ChatSendResponse(val chatId: String, val reply: String, val credits: Int, val creditsUsed: Int)

// ---- Image ----
@Serializable data class ImageGenRequest(val prompt: String, val aspectRatio: String = "1:1", val count: Int = 1, val projectId: String? = null)
@Serializable data class ImageItem(val id: String, val url: String)
@Serializable data class ImageGenResponse(val images: List<ImageItem>, val credits: Int, val creditsUsed: Int)

// ---- Video ----
@Serializable data class VideoGenRequest(val prompt: String, val aspectRatio: String = "9:16", val duration: Int = 5, val imageUrl: String? = null, val projectId: String? = null)
@Serializable data class VideoGenResponse(val generationId: String, val status: String, val credits: Int, val creditsUsed: Int, val estimatedSeconds: Int? = null)
@Serializable data class VideoStatusResponse(val status: String, val videoUrl: String? = null, val error: String? = null, val progress: String? = null, val generationId: String? = null, val credits: Int)

// ---- Voice ----
@Serializable data class VoiceInfo(val id: String, val name: String, val gender: String, val style: String)
@Serializable data class VoiceListResponse(val voices: List<VoiceInfo>)
@Serializable data class VoiceGenRequest(val text: String, val voiceId: String? = null, val speed: Double = 1.0, val language: String = "en", val projectId: String? = null)
@Serializable data class VoiceGenResponse(val id: String, val audioDataUrl: String, val mimeType: String, val extension: String, val credits: Int, val creditsUsed: Int)

// ---- Music ----
@Serializable data class MusicGenRequest(val prompt: String, val mood: String? = null, val genre: String? = null, val duration: Int = 8, val projectId: String? = null)
@Serializable data class MusicGenResponse(val generationId: String, val status: String, val credits: Int, val creditsUsed: Int)
@Serializable data class MusicStatusResponse(val status: String, val audioUrl: String? = null, val error: String? = null, val credits: Int)

// ---- Writer / Prompt ----
@Serializable data class WriterRequest(val category: String, val inputText: String, val language: String = "en", val projectId: String? = null)
@Serializable data class WriterResponse(val id: String, val output: String, val credits: Int, val creditsUsed: Int)
@Serializable data class PromptRequest(val type: String, val idea: String, val language: String = "en", val projectId: String? = null)
@Serializable data class PromptResponse(val id: String, val prompt: String, val credits: Int, val creditsUsed: Int)

// ---- Projects ----
@Serializable data class ProjectItem(val id: String, val name: String, val description: String = "", val itemCount: Int = 0, val updatedAt: String, val createdAt: String)
@Serializable data class ProjectListResponse(val projects: List<ProjectItem>, val credits: Int)
@Serializable data class ProjectCreateRequest(val name: String, val description: String? = null)

// ---- History ----
@Serializable data class GenerationRecord(val id: String, val type: String, val prompt: String, val status: String, val resultUrl: String? = null, val aspectRatio: String? = null, val duration: Int? = null, val creditsUsed: Int = 0, val createdAt: String, val completedAt: String? = null)
@Serializable data class ScriptRecord(val id: String, val category: String, val inputText: String, val outputText: String, val language: String, val createdAt: String)
@Serializable data class HistoryResponse(val generations: List<GenerationRecord>, val scripts: List<ScriptRecord>, val credits: Int)

// ---- Status / errors ----
@Serializable data class AppStatus(val app: String, val version: String, val features: Map<String, Boolean>, val creditCosts: Map<String, Double>)
@Serializable data class ApiError(val error: String)
