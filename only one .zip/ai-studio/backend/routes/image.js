import { Router } from 'express';
import Generation from '../models/Generation.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();

// POST /api/image/generate
// Body: { prompt, aspectRatio (1:1|16:9|9:16), count (1-4), projectId? }
router.post('/generate', generationLimiter, async (req, res) => {
  try {
    const { prompt, aspectRatio, count, projectId } = req.body;
    if (!prompt || !String(prompt).trim()) return res.status(400).json({ error: 'Please enter a prompt.' });
    const aspect = ['1:1', '16:9', '9:16'].includes(aspectRatio) ? aspectRatio : '1:1';
    const n = Math.min(Math.max(parseInt(count || '1', 10), 1), 4);

    const cost = estimateCost('image', { count: n });
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    let urls;
    try {
      const provider = ProviderFactory.getImageProvider();
      urls = await provider.generateImage(String(prompt).slice(0, 2000), { aspectRatio: aspect, count: n });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: 'Image generation is not configured yet. Please connect a supported AI image provider in the backend.' });
      console.error('[image]', err);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    if (!urls || !urls.length) {
      await refundCredits(req.user._id, cost);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    // Save one Generation record per image
    const records = await Promise.all(urls.map(url => Generation.create({
      userId: req.user._id, type: 'image', prompt, aspectRatio: aspect,
      provider: 'openai', status: 'succeeded', resultUrl: url,
      creditsUsed: Math.ceil(cost / urls.length), projectId: projectId || null,
      completedAt: new Date(),
    })));

    res.json({
      images: urls.map((url, i) => ({ id: records[i]._id, url })),
      credits: remaining, creditsUsed: cost,
    });
  } catch (err) {
    console.error('[image]', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// POST /api/image/enhance — upscale/enhance via provider (if supported); otherwise clear message
router.post('/enhance', generationLimiter, async (req, res) => {
  try {
    const { imageUrl } = req.body;
    if (!imageUrl) return res.status(400).json({ error: 'No image to enhance.' });
    // Enhancement via re-generation with "high detail" prompt; swap for a real
    // upscale model adapter (e.g. stabilityai/stable-diffusion-x4-upscaler on Replicate)
    const cost = estimateCost('image', { count: 1 });
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }
    try {
      const provider = ProviderFactory.getImageProvider();
      const urls = await provider.generateImage('high detail, 4k, sharp, professional, enhanced quality version of: ' + String(imageUrl).slice(0, 200), { aspectRatio: '1:1', quality: 'hd' });
      const rec = await Generation.create({ userId: req.user._id, type: 'image', prompt: 'enhanced', provider: 'openai', status: 'succeeded', resultUrl: urls[0], creditsUsed: cost, completedAt: new Date() });
      res.json({ image: { id: rec._id, url: urls[0] }, credits: remaining });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: err.message });
      return res.status(502).json({ error: 'Enhance failed. Please try again.' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Something went wrong.' });
  }
});

// DELETE /api/image/:id
router.delete('/:id', async (req, res) => {
  await Generation.deleteOne({ _id: req.params.id, userId: req.user._id, type: 'image' });
  res.json({ ok: true });
});

export default router;
