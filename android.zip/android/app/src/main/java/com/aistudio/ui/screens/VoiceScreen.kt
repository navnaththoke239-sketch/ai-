package com.aistudio.ui.screens

import android.media.MediaPlayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.data.VoiceGenRequest
import com.aistudio.data.VoiceInfo
import com.aistudio.ui.components.CreditConfirmDialog
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var voices by remember { mutableStateOf<List<VoiceInfo>>(emptyList()) }
    var selectedVoice by remember { mutableStateOf<String?>(null) }
    var speed by remember { mutableStateOf(1.0f) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var audioDataUrl by remember { mutableStateOf<String?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    val cost = (text.length / 100 + 1) * 2

    LaunchedEffect(Unit) { runCatching { voices = vm.api.voices().voices; selectedVoice = voices.firstOrNull()?.id }.onFailure { error = friendlyError(it.message, lang) } }

    fun play(dataUrl: String) {
        runCatching {
            val base64 = dataUrl.substringAfter("base64,")
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            val file = java.io.File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.mp3")
            file.writeBytes(bytes)
            MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); start() }
        }
    }

    fun generate() {
        showConfirm = false; loading = true; error = null; audioDataUrl = null
        scope.launch {
            runCatching {
                val resp = vm.api.generateVoice(VoiceGenRequest(text = text, voiceId = selectedVoice, speed = speed.toDouble(), language = lang))
                vm.user = vm.user?.copy(credits = resp.credits)
                audioDataUrl = resp.audioDataUrl
            }.onFailure { error = friendlyError(it.message, lang) }
            loading = false
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("ai_voice", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(Strings.get("enter_text", lang)) }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
            Spacer(Modifier.height(12.dp))
            Text(Strings.get("select_voice", lang), style = MaterialTheme.typography.labelMedium)
            voices.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { v ->
                        FilterChip(selected = selectedVoice == v.id, onClick = { selectedVoice = v.id }, label = { Text(v.name) }, modifier = Modifier.weight(1f))
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }
            if (voices.isEmpty() && error == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Text("${Strings.get("speed", lang)}: ${"%.1f".format(speed)}x", style = MaterialTheme.typography.labelMedium)
            Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.5f..2f, steps = 14)
            Spacer(Modifier.height(16.dp))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            PrimaryButton(Strings.get("generate", lang), onClick = { showConfirm = true }, enabled = text.isNotBlank() && !loading, loading = loading)

            audioDataUrl?.let { url ->
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Audio ready", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { play(url) }) { Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("preview", lang)) }
                            OutlinedButton(onClick = {
                                val base64 = url.substringAfter("base64,")
                                val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
                                val file = java.io.File(ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "voice_${System.currentTimeMillis()}.mp3")
                                file.writeBytes(bytes)
                                android.widget.Toast.makeText(ctx, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                            }) { Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("download", lang)) }
                        }
                    }
                }
            }
        }
    }
    if (showConfirm) CreditConfirmDialog(cost, lang, onConfirm = { generate() }, onDismiss = { showConfirm = false })
}
