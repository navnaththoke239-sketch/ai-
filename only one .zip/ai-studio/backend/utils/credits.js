import User from '../models/User.js';

// Credit costs per feature. Tunable via env or admin panel later.
// Chat is cheap; video is expensive; voice scales with text length.
export const CREDIT_COSTS = {
  chat_per_message: 1,
  image_per_image: 10,
  video_per_second: 5,   // e.g. 5s video = 25 credits
  voice_per_100_chars: 2,
  music_per_second: 3,
  writer: 3,
  prompt_generator: 2,
};

export function estimateCost(feature, opts = {}) {
  switch (feature) {
    case 'chat': return CREDIT_COSTS.chat_per_message;
    case 'image': return CREDIT_COSTS.image_per_image * (opts.count || 1);
    case 'video': return CREDIT_COSTS.video_per_second * (opts.duration || 5);
    case 'voice': {
      const chars = (opts.text || '').length || 100;
      return Math.ceil(chars / 100) * CREDIT_COSTS.voice_per_100_chars;
    }
    case 'music': return CREDIT_COSTS.music_per_second * (opts.duration || 8);
    case 'writer': return CREDIT_COSTS.writer;
    case 'prompt': return CREDIT_COSTS.prompt_generator;
    default: return 1;
  }
}

// Atomically deduct credits; throws if insufficient.
export async function deductCredits(userId, amount) {
  const user = await User.findById(userId);
  if (!user) throw new Error('User not found');
  if (user.credits < amount) {
    const err = new Error('Your credits are insufficient.');
    err.code = 'INSUFFICIENT_CREDITS';
    throw err;
  }
  user.credits -= amount;
  await user.save();
  return user.credits;
}

// Refund (e.g. generation failed)
export async function refundCredits(userId, amount) {
  const user = await User.findById(userId);
  if (!user) return 0;
  user.credits = Math.max(0, user.credits + amount);
  await user.save();
  return user.credits;
}
