import { Router } from 'express';
import multer from 'multer';
import fetch from 'node-fetch';
import Generation from '../models/Generation.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// ============================================================
// REAL VIDEO GENERATION — no fakes, no placeholders.
// Flow:
//   1. POST /api/video/generate  -> deduct credits, submit job to real provider (Replicate),
//      return { generationId, status: 'processing' }
//   2. App polls GET /api/video/status/:generationId  -> provider job status
//   3. On success, resultUrl is a REAL .mp4 returned by the provider.
// If no provider key is configured, returns 503 with a clear message.
// ============================================================

// POST /api/video/generate
// Body (multipart or JSON): { prompt, aspectRatio, duration, image? (base64/data-url or uploaded file), projectId? }
router.post('/generate', generationLimiter, upload.single('image'), async (req, res) => {
  try {
    const { prompt, aspectRatio, duration, projectId } = req.body;
    const aspect = ['1:1', '16:9', '9:16'].includes(aspectRatio) ? aspectRatio : '9:16';
    const dur = Math.min(Math.max(parseInt(duration || '5', 10), 3), 15); // clamp 3–15s

    if (!prompt && !req.file) {
      return res.status(400).json({ error: 'Please enter a prompt or upload an image.' });
    }

    const cost = estimateCost('video', { duration: dur });
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    // If image uploaded, we need a public URL for the provider. For simplicity we
    // expect the app to pass an imageUrl (uploaded to your storage) OR a data URL.
    // Here we accept a data URL in req.body.imageUrl and pass it through.
    const imageUrl = req.body.imageUrl || null;

    let provider, job;
    try {
      provider = ProviderFactory.getVideoProvider();
      job = await provider.generateVideo(prompt || 'animate this image', {
        aspectRatio: aspect, duration: dur, imageUrl,
      });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) {
        return res.status(503).json({ error: 'Video generation is not configured yet. Please connect a supported AI video provider in the backend.' });
      }
      console.error('[video/generate]', err);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    const gen = await Generation.create({
      userId: req.user._id,
      type: 'video',
      prompt: prompt || '',
      aspectRatio: aspect,
      duration: dur,
      provider: provider.name,
      providerJobId: job.jobId,
      status: 'processing',
      creditsUsed: cost,
      projectId: projectId || null,
    });

    res.status(202).json({
      generationId: gen._id,
      status: 'processing',
      credits: remaining,
      creditsUsed: cost,
      estimatedSeconds: dur * 8, // rough ETA for progress UI
    });
  } catch (err) {
    console.error('[video/generate]', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// GET /api/video/status/:generationId  — polled by the app
router.get('/status/:generationId', async (req, res) => {
  try {
    const gen = await Generation.findOne({ _id: req.params.generationId, userId: req.user._id });
    if (!gen) return res.status(404).json({ error: 'Generation not found.' });

    // Already finished?
    if (gen.status === 'succeeded') {
      return res.json({ status: 'succeeded', videoUrl: gen.resultUrl, generationId: gen._id, credits: req.user.credits });
    }
    if (gen.status === 'failed') {
      return res.json({ status: 'failed', error: gen.errorMessage || 'Generation failed. Please try again.', credits: req.user.credits });
    }

    // Poll the real provider
    const provider = ProviderFactory.getVideoProvider();
    const s = await provider.getVideoStatus(gen.providerJobId);

    if (s.status === 'succeeded' && s.videoUrl) {
      gen.status = 'succeeded';
      gen.resultUrl = s.videoUrl;
      gen.completedAt = new Date();
      await gen.save();
      return res.json({ status: 'succeeded', videoUrl: s.videoUrl, generationId: gen._id, credits: req.user.credits });
    }
    if (s.status === 'failed') {
      gen.status = 'failed';
      gen.errorMessage = s.error ? String(s.error).slice(0, 300) : 'Generation failed.';
      gen.completedAt = new Date();
      await gen.save();
      // Refund on failure
      await refundCredits(req.user._id, gen.creditsUsed);
      return res.json({ status: 'failed', error: 'Generation failed. Please try again.', credits: req.user.credits + gen.creditsUsed });
    }

    // Still processing
    res.json({ status: 'processing', progress: s.progress, generationId: gen._id, credits: req.user.credits });
  } catch (err) {
    if (err instanceof ProviderNotConfiguredError) {
      return res.status(503).json({ error: 'Video generation is not configured yet. Please connect a supported AI video provider in the backend.' });
    }
    console.error('[video/status]', err);
    res.status(500).json({ error: 'Server is busy. Please try again later.' });
  }
});

// GET /api/video/proxy?url=...  — stream the video through the backend so the app
// never needs the provider's signed URL directly (also lets us track downloads).
router.get('/proxy', async (req, res) => {
  const url = req.query.url;
  if (!url || typeof url !== 'string') return res.status(400).end();
  try {
    const upstream = await fetch(url);
    if (!upstream.ok) return res.status(502).json({ error: 'Video unavailable.' });
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'video/mp4');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    upstream.body.pipe(res);
  } catch (e) {
    res.status(502).json({ error: 'Could not load video.' });
  }
});

// DELETE /api/video/:generationId
router.delete('/:generationId', async (req, res) => {
  await Generation.deleteOne({ _id: req.params.generationId, userId: req.user._id, type: 'video' });
  res.json({ ok: true });
});

export default router;
