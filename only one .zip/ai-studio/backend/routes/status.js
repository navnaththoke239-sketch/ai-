import { Router } from 'express';
import mongoose from 'mongoose';
import ProviderFactory from '../providers/ProviderFactory.js';

const router = Router();

// Public status endpoint: tells the app which features are configured
// so it can show friendly "not configured" messages without trying to generate.
router.get('/status', (req, res) => {
  res.json({
    app: 'AI Studio',
    version: '1.0.0',
    features: ProviderFactory.getStatus(),
    creditCosts: {
      chat_per_message: 1,
      image_per_image: 10,
      video_per_second: 5,
      voice_per_100_chars: 2,
      music_per_second: 3,
      writer: 3,
      prompt_generator: 2,
    },
  });
});

// Health check
router.get('/health', (req, res) => {
  const dbState = mongoose.connection.readyState;
  res.json({ ok: true, db: dbState === 1 ? 'connected' : 'disconnected', uptime: process.uptime() });
});

export default router;
