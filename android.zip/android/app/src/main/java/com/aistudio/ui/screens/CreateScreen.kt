package com.aistudio.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aistudio.AppViewModel
import com.aistudio.utils.Strings

data class CreateOption(val key: String, val icon: ImageVector, val route: String, val desc: String)

val CREATE_OPTIONS = listOf(
    CreateOption("ai_chat", Icons.Default.Chat, "chat", "Talk to AI, get ideas & answers"),
    CreateOption("ai_image", Icons.Default.Image, "image", "Text to image"),
    CreateOption("ai_video", Icons.Default.Movie, "video", "Text or image to video"),
    CreateOption("ai_voice", Icons.Default.Mic, "voice", "Text to speech"),
    CreateOption("ai_music", Icons.Default.MusicNote, "music", "Background music"),
    CreateOption("ai_writer", Icons.Default.Edit, "writer", "Scripts, titles, captions, stories"),
)

@Composable
fun CreateScreen(vm: AppViewModel, nav: NavHostController) {
    val lang = vm.language
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(Strings.get("choose_tool", lang), style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text("Choose tool → enter prompt → Generate → Preview → Save/Download/Share", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(CREATE_OPTIONS) { opt ->
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { nav.navigate(opt.route) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(opt.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(Strings.get(opt.key, lang), style = MaterialTheme.typography.titleMedium)
                            Text(opt.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }
        }
    }
}
