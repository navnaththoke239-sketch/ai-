package com.aistudio.data

import com.aistudio.BuildConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

interface ApiService {

    // Auth
    @POST("auth/signup") suspend fun signup(@Body req: AuthRequest): AuthResponse
    @POST("auth/login") suspend fun login(@Body req: AuthRequest): AuthResponse
    @GET("auth/me") suspend fun me(): retrofit2.Response<AuthResponse>

    // Status
    @GET("status") suspend fun status(): AppStatus

    // Chat
    @GET("chat") suspend fun chatList(): ChatListResponse
    @GET("chat/{id}") suspend fun chatDetail(@Path("id") id: String): retrofit2.Response<okhttp3.ResponseBody>
    @POST("chat") suspend fun chatSend(@Body req: ChatSendRequest): ChatSendResponse
    @DELETE("chat/{id}") suspend fun chatDelete(@Path("id") id: String): retrofit2.Response<okhttp3.ResponseBody>

    // Image
    @POST("image/generate") suspend fun generateImage(@Body req: ImageGenRequest): ImageGenResponse
    @POST("image/enhance") suspend fun enhanceImage(@Body map: Map<String, String>): ImageGenResponse
    @DELETE("image/{id}") suspend fun deleteImage(@Path("id") id: String): retrofit2.Response<okhttp3.ResponseBody>

    // Video
    @POST("video/generate") suspend fun generateVideo(@Body req: VideoGenRequest): VideoGenResponse
    @GET("video/status/{id}") suspend fun videoStatus(@Path("id") id: String): VideoStatusResponse
    @DELETE("video/{id}") suspend fun deleteVideo(@Path("id") id: String): retrofit2.Response<okhttp3.ResponseBody>

    // Voice
    @GET("voice/voices") suspend fun voices(): VoiceListResponse
    @POST("voice/generate") suspend fun generateVoice(@Body req: VoiceGenRequest): VoiceGenResponse

    // Music
    @POST("music/generate") suspend fun generateMusic(@Body req: MusicGenRequest): MusicGenResponse
    @GET("music/status/{id}") suspend fun musicStatus(@Path("id") id: String): MusicStatusResponse

    // Writer
    @POST("writer/generate") suspend fun writerGenerate(@Body req: WriterRequest): WriterResponse

    // Prompt
    @POST("prompt/generate") suspend fun promptGenerate(@Body req: PromptRequest): PromptResponse

    // Projects
    @GET("projects") suspend fun projects(): ProjectListResponse
    @POST("projects") suspend fun createProject(@Body req: ProjectCreateRequest): retrofit2.Response<okhttp3.ResponseBody>
    @PUT("projects/{id}") suspend fun renameProject(@Path("id") id: String, @Body map: Map<String, String>): retrofit2.Response<okhttp3.ResponseBody>
    @DELETE("projects/{id}") suspend fun deleteProject(@Path("id") id: String): retrofit2.Response<okhttp3.ResponseBody>

    // History
    @GET("chat/history/all") suspend fun history(): HistoryResponse

    companion object {
        fun create(tokenProvider: suspend () -> String?): ApiService {
            val authInterceptor = Interceptor { chain ->
                val token = runBlocking { tokenProvider() }
                val req = chain.request().newBuilder().apply {
                    if (!token.isNullOrBlank()) header("Authorization", "Bearer $token")
                }.build()
                chain.proceed(req)
            }
            val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
            val client = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(logging)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build()
            val retrofit = Retrofit.Builder()
                .baseUrl(BuildConfig.BASE_URL)
                .client(client)
                .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
                .build()
            return retrofit.create(ApiService::class.java)
        }
    }
}
