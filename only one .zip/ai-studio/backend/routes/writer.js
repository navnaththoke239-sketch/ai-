import { Router } from 'express';
import Script from '../models/Script.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();

const SYSTEM_PROMPTS = {
  youtube_shorts: 'Write a punchy YouTube Shorts script (under 60 seconds) with hook, body and call-to-action. Include scene cues.',
  youtube_title: 'Generate 5 catchy, click-worthy YouTube video titles. Return only the titles, numbered.',
  youtube_description: 'Write an SEO-friendly YouTube video description with keywords, timestamps and links.',
  caption: 'Write engaging social media captions (3 options) with relevant hashtags.',
  story: 'Write a short, engaging story with a clear beginning, middle and end.',
  dialogue: 'Write a natural, expressive dialogue scene between two characters.',
  anime_story: 'Write an anime-style story with vivid characters, dramatic twists and Japanese-inspired naming.',
  funny_script: 'Write a short, genuinely funny comedy script with setup and punchline.',
  voiceover: 'Write a smooth voice-over script that is easy to narrate aloud.',
  translation: 'Translate the given text accurately. Preserve tone and meaning.',
  rewrite: 'Rewrite the given text to improve clarity, flow and engagement while keeping the same meaning.',
};

// POST /api/writer/generate
// Body: { category, inputText, language, projectId? }
router.post('/generate', generationLimiter, async (req, res) => {
  try {
    const { category, inputText, language, projectId } = req.body;
    if (!SYSTEM_PROMPTS[category]) return res.status(400).json({ error: 'Unknown writer tool.' });
    const langName = { en: 'English', hi: 'Hindi', mr: 'Marathi' }[language] || 'English';

    const cost = estimateCost('writer');
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    let output;
    try {
      const provider = ProviderFactory.getChatProvider();
      const messages = [
        { role: 'system', content: `${SYSTEM_PROMPTS[category]} Reply in ${langName}.` },
        { role: 'user', content: inputText || `Please ${SYSTEM_PROMPTS[category].toLowerCase()}` },
      ];
      output = await provider.chat(messages, { temperature: 0.8, max_tokens: 1500 });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: 'AI Writer is not configured yet. Please connect a supported AI provider in the backend.' });
      console.error('[writer]', err);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    const rec = await Script.create({
      userId: req.user._id, category, inputText: String(inputText || '').slice(0, 2000),
      outputText: output, language: language || 'en', projectId: projectId || null, creditsUsed: cost,
    });

    res.json({ id: rec._id, output, credits: remaining, creditsUsed: cost });
  } catch (err) {
    console.error('[writer]', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

export default router;
