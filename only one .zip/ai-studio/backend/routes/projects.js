import { Router } from 'express';
import Project from '../models/Project.js';
import Chat from '../models/Chat.js';
import Generation from '../models/Generation.js';
import Script from '../models/Script.js';

const router = Router();

// GET /api/projects — list
router.get('/', async (req, res) => {
  const projects = await Project.find({ userId: req.user._id }).sort({ updatedAt: -1 });
  res.json({
    projects: projects.map(p => ({
      id: p._id, name: p.name, description: p.description,
      itemCount: (p.chatIds?.length || 0) + (p.generationIds?.length || 0) + (p.scriptIds?.length || 0),
      updatedAt: p.updatedAt, createdAt: p.createdAt,
    })),
    credits: req.user.credits,
  });
});

// GET /api/projects/:id — detail with populated content
router.get('/:id', async (req, res) => {
  const p = await Project.findOne({ _id: req.params.id, userId: req.user._id });
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  const [chats, gens, scripts] = await Promise.all([
    Chat.find({ _id: { $in: p.chatIds || [] } }),
    Generation.find({ _id: { $in: p.generationIds || [] } }),
    Script.find({ _id: { $in: p.scriptIds || [] } }),
  ]);
  res.json({ project: p, chats, generations: gens, scripts, credits: req.user.credits });
});

// POST /api/projects — create
router.post('/', async (req, res) => {
  const { name, description } = req.body;
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'Please enter a project name.' });
  const p = await Project.create({ userId: req.user._id, name: String(name).slice(0, 200), description: String(description || '').slice(0, 1000) });
  res.status(201).json({ project: { id: p._id, name: p.name, description: p.description, createdAt: p.createdAt } });
});

// PUT /api/projects/:id — rename / update
router.put('/:id', async (req, res) => {
  const p = await Project.findOne({ _id: req.params.id, userId: req.user._id });
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  if (req.body.name) p.name = String(req.body.name).slice(0, 200);
  if (typeof req.body.description === 'string') p.description = req.body.description.slice(0, 1000);
  p.updatedAt = new Date();
  await p.save();
  res.json({ project: { id: p._id, name: p.name, description: p.description } });
});

// POST /api/projects/:id/add — attach a chat/generation/script to the project
router.post('/:id/add', async (req, res) => {
  const p = await Project.findOne({ _id: req.params.id, userId: req.user._id });
  if (!p) return res.status(404).json({ error: 'Project not found.' });
  const { chatId, generationId, scriptId } = req.body;
  if (chatId && !p.chatIds.includes(chatId)) p.chatIds.push(chatId);
  if (generationId && !p.generationIds.includes(generationId)) p.generationIds.push(generationId);
  if (scriptId && !p.scriptIds.includes(scriptId)) p.scriptIds.push(scriptId);
  p.updatedAt = new Date();
  await p.save();
  res.json({ ok: true });
});

// DELETE /api/projects/:id
router.delete('/:id', async (req, res) => {
  await Project.deleteOne({ _id: req.params.id, userId: req.user._id });
  // Note: content (chats/generations) is kept; only the grouping is removed.
  res.json({ ok: true });
});

export default router;
