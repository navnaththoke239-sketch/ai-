// Base class for all AI providers. Every real provider adapter extends this.
// If a method is not overridden, it throws a clear "not supported" error
// (never fake content). The route layer catches these and returns friendly messages.

export class ProviderNotConfiguredError extends Error {
  constructor(feature) {
    super(`${feature} is not configured yet. Please connect a supported AI provider in the backend.`);
    this.name = 'ProviderNotConfiguredError';
    this.feature = feature;
  }
}

export class ProviderUnsupportedError extends Error {
  constructor(feature, provider) {
    super(`${provider} does not support ${feature}.`);
    this.name = 'ProviderUnsupportedError';
  }
}

export default class BaseProvider {
  constructor(name) {
    this.name = name;
  }

  // ---- Chat / text completion ----
  async chat(messages, opts = {}) {
    throw new ProviderUnsupportedError('chat', this.name);
  }

  // ---- Image ----
  async generateImage(prompt, opts = {}) {
    throw new ProviderUnsupportedError('image generation', this.name);
  }

  // ---- Video (async job model) ----
  // Returns { jobId } immediately; status polled via getVideoStatus
  async generateVideo(prompt, opts = {}) {
    throw new ProviderUnsupportedError('video generation', this.name);
  }
  async getVideoStatus(jobId) {
    throw new ProviderUnsupportedError('video status', this.name);
  }

  // ---- Voice / TTS ----
  // Returns audio Buffer + mimeType
  async generateVoice(text, opts = {}) {
    throw new ProviderUnsupportedError('voice generation', this.name);
  }
  listVoices() {
    throw new ProviderUnsupportedError('voice list', this.name);
  }

  // ---- Music ----
  async generateMusic(prompt, opts = {}) {
    throw new ProviderUnsupportedError('music generation', this.name);
  }
  async getMusicStatus(jobId) {
    throw new ProviderUnsupportedError('music status', this.name);
  }
}
