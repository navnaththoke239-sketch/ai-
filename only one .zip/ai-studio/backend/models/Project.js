import mongoose from 'mongoose';

const projectSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 200 },
  description: { type: String, default: '', maxlength: 1000 },
  // References to content inside the project (populated on read)
  chatIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Chat' }],
  generationIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Generation' }],
  scriptIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Script' }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

projectSchema.index({ userId: 1, updatedAt: -1 });

export default mongoose.model('Project', projectSchema);
