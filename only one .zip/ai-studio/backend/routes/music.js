import { Router } from 'express';
import Generation from '../models/Generation.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();

// POST /api/music/generate — async job (like video)
// Body: { prompt, mood, genre, duration, projectId? }
router.post('/generate', generationLimiter, async (req, res) => {
  try {
    const { prompt, mood, genre, duration, projectId } = req.body;
    const dur = Math.min(Math.max(parseInt(duration || '8', 10), 2), 30);

    const cost = estimateCost('music', { duration: dur });
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    let provider, job;
    try {
      provider = ProviderFactory.getMusicProvider();
      job = await provider.generateMusic(prompt || 'instrumental background music', { mood, genre, duration: dur });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: 'Music generation is not configured yet. Please connect a supported AI music provider in the backend.' });
      console.error('[music]', err);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    const gen = await Generation.create({
      userId: req.user._id, type: 'music', prompt: prompt || '', mood, genre, duration: dur,
      provider: provider.name, providerJobId: job.jobId, status: 'processing',
      creditsUsed: cost, projectId: projectId || null,
    });

    res.status(202).json({ generationId: gen._id, status: 'processing', credits: remaining, creditsUsed: cost });
  } catch (err) {
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// GET /api/music/status/:generationId
router.get('/status/:generationId', async (req, res) => {
  try {
    const gen = await Generation.findOne({ _id: req.params.generationId, userId: req.user._id });
    if (!gen) return res.status(404).json({ error: 'Generation not found.' });
    if (gen.status === 'succeeded') return res.json({ status: 'succeeded', audioUrl: gen.resultUrl, credits: req.user.credits });
    if (gen.status === 'failed') return res.json({ status: 'failed', error: gen.errorMessage || 'Generation failed.', credits: req.user.credits });

    const provider = ProviderFactory.getMusicProvider();
    const s = await provider.getMusicStatus(gen.providerJobId);
    if (s.status === 'succeeded' && s.audioUrl) {
      gen.status = 'succeeded'; gen.resultUrl = s.audioUrl; gen.completedAt = new Date();
      await gen.save();
      return res.json({ status: 'succeeded', audioUrl: s.audioUrl, credits: req.user.credits });
    }
    if (s.status === 'failed') {
      gen.status = 'failed'; gen.errorMessage = String(s.error || '').slice(0, 300); gen.completedAt = new Date();
      await gen.save();
      await refundCredits(req.user._id, gen.creditsUsed);
      return res.json({ status: 'failed', error: 'Generation failed. Please try again.', credits: req.user.credits + gen.creditsUsed });
    }
    res.json({ status: 'processing', credits: req.user.credits });
  } catch (err) {
    if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: err.message });
    res.status(500).json({ error: 'Server is busy. Please try again later.' });
  }
});

export default router;
