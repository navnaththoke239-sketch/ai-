# AI Studio — Complete Setup Guide

A full all-in-one AI app: **Android (Kotlin + Jetpack Compose)** + **secure Node.js backend** + **admin panel**.
Chat, image, video, voice, music, writer, prompt generator, projects, credits, auth — all real, no fakes.

```
ai-studio/
├── android/          # Android app source (Kotlin + Compose)
├── backend/          # Node.js + Express + MongoDB backend
├── admin/            # Admin web panel (served by backend at /admin)
└── SETUP.md          # this file
```

---

## 1. Configure the Backend

### Prerequisites
- Node.js ≥ 18
- MongoDB (local install, or free **MongoDB Atlas** cloud cluster)
- A domain / server for production (Render, Railway, Fly.io, AWS, etc.)

### Steps
```bash
cd backend
cp .env.example .env          # then edit .env with real values
npm install
npm run dev                   # starts on http://localhost:5000
```

### Where to add AI provider API keys
Open `backend/.env` and fill in the keys you want to use. **Keys live only here — never in the Android APK.**

| Feature | Provider | Env variable | Where to get the key |
|---|---|---|---|
| Chat / Writer / Prompt / Image (DALL-E) | OpenAI (or any OpenAI-compatible endpoint) | `OPENAI_API_KEY` | platform.openai.com/api-keys |
| **Video (text-to-video + image-to-video)** | **Replicate** (real video API) | `REPLICATE_API_TOKEN` | replicate.com/account/api-tokens |
| Music (meta/musicgen) | Replicate | `REPLICATE_API_TOKEN` | (same as above) |
| Voice / TTS (Hindi + English + multilingual) | ElevenLabs | `ELEVENLABS_API_KEY` | elevenlabs.io → Profile → API Keys |

Leave a key empty → that feature shows a clear *"not configured yet"* message in the app. **Nothing is faked.**

#### Video model selection (in `.env`)
```bash
# Defaults already set; swap if desired:
REPLICATE_TEXT_TO_VIDEO_MODEL=luma-ai/ray2
# alternatives: anotherjesse/zeroscope-v2-xl , lucataco/animate-diff
REPLICATE_IMAGE_TO_VIDEO_MODEL=stability-ai/stable-video-diffusion:3f0457e4619daac51203dedb472816fd4af51f3149fa7a9e0b5ffcf1b8172438
```
To add Runway / Pika / Kling / Luma API: create a new adapter class in `backend/providers/` (extend `BaseProvider`) and wire it in `ProviderFactory.js`. The Android UI needs **zero changes**.

### Database credentials
In `.env`:
```bash
# Local MongoDB:
MONGODB_URI=mongodb://localhost:27017/ai-studio
# Or MongoDB Atlas (production):
MONGODB_URI=mongodb+srv://<user>:<password>@<cluster>.mongodb.net/ai-studio?retryWrites=true&w=majority
```
Generate a strong JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
# paste into JWT_SECRET=
```
Set `ADMIN_EMAIL=you@example.com` — the first account signed up with that email becomes admin.

---

## 2. How the REAL video generation works

```
Android app                      Backend                          AI Provider (Replicate)
─────────────                    ─────────                        ─────────────────────
POST /api/video/generate  ──►   deduct credits              ──►  POST /predictions
{prompt, aspect, duration,       create Generation record        (real video model)
 imageUrl?}                       store provider jobId   ◄──      returns job id
                                 return {generationId}
GET /api/video/status/{id} ──►   GET /predictions/{jobId}  ──►   (poll every 5s)
                                 until status=succeeded   ◄──     returns .mp4 URL
                                 return {videoUrl}
Android plays REAL .mp4 in ExoPlayer. Download / Share / Regenerate / Delete available.
```

Endpoints (in `backend/routes/video.js`):
- `POST /api/video/generate` → `{ generationId, status, credits, estimatedSeconds }`
- `GET  /api/video/status/{generationId}` → `{ status: processing|succeeded|failed, videoUrl?, error? }`
- `GET  /api/video/proxy?url=...` → streams the video through your backend
- `DELETE /api/video/{generationId}`

**If no `REPLICATE_API_TOKEN` is set**, the endpoint returns HTTP 503 with:
> *"Video generation is not configured yet. Please connect a supported AI video provider in the backend."*

The app shows this message to the user. It never shows a fake/placeholder video.

---

## 3. Build the Android APK

### Prerequisites
- Android Studio (Hedgehog or newer)
- JDK 17
- Android SDK 34

### Steps
1. Open Android Studio → **Open** → select the `ai-studio/android` folder.
2. Let Gradle sync (downloads dependencies automatically).
3. Set your backend URL in `android/app/build.gradle.kts`:
   ```kotlin
   // debug (emulator — 10.0.2.2 maps to host's localhost):
   buildConfigField("String", "BASE_URL", "\"http://10.0.2.2:5000/api/\"")
   // release (your deployed backend — MUST be https):
   buildConfigField("String", "BASE_URL", "\"https://your-backend.example.com/api/\"")
   ```
   ⚠️ **No API keys anywhere in the Android project.** The app only holds the backend URL + a JWT.
4. **Debug APK:** `Build → Build Bundle(s)/APK(s) → Build APK(s)` → installs on emulator/device.
5. **Release APK:** `Build → Generate Signed Bundle / APK` → create a keystore → signed APK in `android/app/release/`.

Command-line alternative:
```bash
cd android
./gradlew assembleDebug     # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease   # signed release (requires signing config)
```

### Permissions handled
- `INTERNET` (required)
- `READ_MEDIA_IMAGES` / `READ_EXTERNAL_STORAGE` (gallery picker for image-to-video)
- Files saved to app-specific `Downloads/` via `MediaStore` (no broad storage permission needed on API 29+)
- Sharing via `FileProvider` + Android Sharesheet (`res/xml/file_paths.xml`)

---

## 4. Test each AI feature

Start the backend (`npm run dev`) and run the app on an emulator. Sign up (first admin email becomes admin).

| Feature | How to test | Expected real result |
|---|---|---|
| **Chat** | Home → AI Chat → type "write a short story" | Real AI reply in chosen language (en/hi/mr) |
| **Image** | Home → AI Image → prompt → Generate | Real generated image(s), downloadable |
| **Video** | Home → AI Video → prompt + choose 9:16 + 5s → Generate | Progress screen → real playable MP4 in ExoPlayer (1–5 min) |
| **Voice** | Home → AI Voice → type text → pick voice → Generate | Real playable MP3 audio (Hindi/English supported) |
| **Music** | Home → AI Music → describe + mood/genre → Generate | Real generated MP3 background music |
| **Writer** | Home → AI Writer → pick tool → topic | Real generated script/title/caption/story |
| **Prompt Gen** | Home → Prompt Generator → type + type | Detailed copy-ready prompt |
| **Projects** | Bottom → Projects → + create | Rename / delete works; generations attachable |
| **Credits** | Any expensive generation | Confirm dialog shows cost; balance decrements; failure refunds |
| **Admin** | Visit `http://localhost:5000/admin` → login with admin email | See users, set credits, view usage, provider status |

If a provider key is missing, that feature shows the friendly "not configured" message — this is **by design**, not a bug.

---

## 5. Deploy the backend securely

### Recommended: Render / Railway / Fly.io
1. Push `backend/` to a GitHub repo.
2. Create a new Web Service → connect repo → build command `npm install` → start `npm start`.
3. Add **all** `.env` variables in the platform's Secrets/Environment settings (never commit `.env`).
4. Attach MongoDB Atlas (or platform-managed Postgres — swap Mongoose for Prisma if preferred).
5. Enforce HTTPS (platform handles it). Set `CORS_ORIGINS` to your admin domain.
6. In production set `NODE_ENV=production`.

### Security checklist (already implemented in code)
- ✅ API keys **only** in backend env vars — never in APK
- ✅ JWT auth on every protected route (`middleware/auth.js`)
- ✅ Bcrypt password hashing (12 rounds)
- ✅ Rate limiting: 100 req/15min general, 20/15min generation, 10/15min auth (`middleware/rateLimit.js`)
- ✅ Helmet security headers + CORS allowlist
- ✅ Input validation with `express-validator` + length caps
- ✅ Credit deduction **before** generation; automatic **refund on failure**
- ✅ Clear user-facing errors; technical errors logged server-side only
- ✅ Provider abstraction — swap providers without touching Android code
- ✅ Unconfigured providers return 503 + friendly message — never fake content

### Add Google login (optional)
1. Set up Google Identity / Firebase Auth.
2. Add `POST /api/auth/google` route: verify the Google ID token (backend), find/create user, return JWT.
3. In Android, add Google Sign-In button in `LoginScreen.kt` (commented placeholder), send `idToken` to backend.

---

## 6. Project structure & extending

**Add a new AI provider** (e.g. Runway video):
1. `backend/providers/RunwayProvider.js` → extend `BaseProvider`, implement `generateVideo` + `getVideoStatus`.
2. In `ProviderFactory.getVideoProvider()`, return it based on an env flag.
3. Done — Android app unchanged.

**Change credit costs:** edit `backend/utils/credits.js` (or move to `AppSetting` DB collection for admin-editable).

**Free / open-source models for development:**
- Chat: Ollama (local) or Groq free tier — point `OPENAI_BASE_URL` at any OpenAI-compatible endpoint.
- Image: Stable Diffusion via Replicate (pay-per-use, cheap) or local ComfyUI.
- Video: Replicate (Zeroscope, Stable Video Diffusion) — real models, pay-per-generation.
- Voice: Coqui TTS (open-source, self-host) — add a `CoquiProvider` adapter.
- Music: MusicGen via Replicate, or self-host audiocraft.

---

## Troubleshooting
- **App says "not configured"** → add the relevant API key in `backend/.env` and restart.
- **Video generation times out** → increase poll attempts in `VideoScreen.kt` (default 120 × 5s = 10 min).
- **CORS errors** → add your admin/frontend origin to `CORS_ORIGINS` in `.env`.
- **MongoDB connection fails** → check `MONGODB_URI`; Atlas requires whitelisting your server IP.
- **APK can't reach backend on physical device** → use your machine's LAN IP, not `10.0.2.2` (that's emulator-only).
