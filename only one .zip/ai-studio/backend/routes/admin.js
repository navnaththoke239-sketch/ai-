import { Router } from 'express';
import User from '../models/User.js';
import Generation from '../models/Generation.js';
import AppSetting from '../models/AppSetting.js';
import ProviderFactory from '../providers/ProviderFactory.js';

const router = Router();

// GET /api/admin/stats — overview
router.get('/stats', async (req, res) => {
  const [userCount, totalCredits, genStats] = await Promise.all([
    User.countDocuments(),
    User.aggregate([{ $group: { _id: null, total: { $sum: '$credits' } } }]),
    Generation.aggregate([
      { $group: { _id: { type: '$type', status: '$status' }, count: { $sum: 1 }, credits: { $sum: '$creditsUsed' } } },
    ]),
  ]);
  res.json({
    userCount,
    totalCreditsInSystem: totalCredits[0]?.total || 0,
    generationStats: genStats,
    providers: ProviderFactory.getStatus(),
  });
});

// GET /api/admin/users — list users
router.get('/users', async (req, res) => {
  const users = await User.find().select('-password').sort({ createdAt: -1 }).limit(500);
  res.json({ users });
});

// PUT /api/admin/users/:id/credits — set/ adjust credits
router.put('/users/:id/credits', async (req, res) => {
  const { credits } = req.body;
  if (typeof credits !== 'number' || credits < 0) return res.status(400).json({ error: 'Invalid credit amount.' });
  const u = await User.findByIdAndUpdate(req.params.id, { credits }, { new: true }).select('-password');
  if (!u) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: u });
});

// GET /api/admin/generations — recent generations (usage log)
router.get('/generations', async (req, res) => {
  const gens = await Generation.find().sort({ createdAt: -1 }).limit(200).populate('userId', 'name email');
  res.json({ generations: gens });
});

// GET /api/admin/settings
router.get('/settings', async (req, res) => {
  const settings = await AppSetting.find();
  res.json({ settings: settings.map(s => ({ key: s.key, value: s.value })) });
});

// PUT /api/admin/settings — enable/disable models, set credit costs, etc.
router.put('/settings', async (req, res) => {
  const { key, value } = req.body;
  if (!key) return res.status(400).json({ error: 'Missing key.' });
  await AppSetting.findOneAndUpdate({ key }, { key, value, updatedAt: new Date() }, { upsert: true });
  res.json({ ok: true });
});

export default router;
