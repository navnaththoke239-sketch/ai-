import { Router } from 'express';
import Script from '../models/Script.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();

// Detailed prompt templates per type. The AI expands the user's short idea
// into a copy-ready, detailed prompt.
const PROMPT_GUIDES = {
  prompt_image: 'Expand this idea into a detailed, copy-ready text-to-image prompt. Include subject, setting, lighting, style, camera angle, color palette and mood. One paragraph, ready to paste into an image generator.',
  prompt_video: 'Expand this idea into a detailed text-to-video prompt. Describe the scene, motion, camera movement, characters, lighting, mood and style. Ready to paste into a video generator.',
  prompt_anime: 'Write a detailed anime-style image/video prompt with character design, art style (e.g. Studio Ghibli / Makoto Shinkai), vibrant colors, dynamic pose and background.',
  prompt_cat: 'Write a funny, viral cat or funny-animal short-video prompt. Include cute/funny action, setting, punchline moment and caption idea. Ready to generate.',
  prompt_youtube: 'Write a YouTube content idea with title, hook, outline, thumbnail concept and description keywords, all based on the user topic.',
  prompt_voice: 'Write a short voice-over script optimized for AI TTS: clear sentences, natural pauses, emotional tone notes, and suggest a voice style (narrator/cute/energetic).',
};

// POST /api/prompt/generate
// Body: { type (prompt_image|prompt_video|...), idea, language, projectId? }
router.post('/generate', generationLimiter, async (req, res) => {
  try {
    const { type, idea, language, projectId } = req.body;
    if (!PROMPT_GUIDES[type]) return res.status(400).json({ error: 'Unknown prompt type.' });
    if (!idea || !String(idea).trim()) return res.status(400).json({ error: 'Please enter a short idea.' });
    const langName = { en: 'English', hi: 'Hindi', mr: 'Marathi' }[language] || 'English';

    const cost = estimateCost('prompt');
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    let output;
    try {
      const provider = ProviderFactory.getChatProvider();
      output = await provider.chat([
        { role: 'system', content: `${PROMPT_GUIDES[type]} Reply in ${langName}.` },
        { role: 'user', content: String(idea).slice(0, 500) },
      ], { temperature: 0.9, max_tokens: 600 });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: 'Prompt Generator is not configured yet. Please connect a supported AI provider in the backend.' });
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    const rec = await Script.create({
      userId: req.user._id, category: type, inputText: String(idea).slice(0, 500),
      outputText: output, language: language || 'en', projectId: projectId || null, creditsUsed: cost,
    });

    res.json({ id: rec._id, prompt: output, credits: remaining, creditsUsed: cost });
  } catch (err) {
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

export default router;
