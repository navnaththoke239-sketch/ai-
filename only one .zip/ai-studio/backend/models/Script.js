import mongoose from 'mongoose';

// Writer / prompt outputs stored as scripts (text artifacts)
const scriptSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  category: {
    type: String,
    enum: [
      'youtube_shorts', 'youtube_title', 'youtube_description', 'caption',
      'story', 'dialogue', 'anime_story', 'funny_script', 'voiceover',
      'translation', 'rewrite', 'prompt_image', 'prompt_video', 'prompt_anime',
      'prompt_cat', 'prompt_youtube', 'prompt_voice',
    ],
    required: true,
  },
  inputText: { type: String, default: '' },
  outputText: { type: String, required: true },
  language: { type: String, enum: ['en', 'hi', 'mr'], default: 'en' },
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', default: null, index: true },
  creditsUsed: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now, index: true },
});

scriptSchema.index({ userId: 1, createdAt: -1 });

export default mongoose.model('Script', scriptSchema);
