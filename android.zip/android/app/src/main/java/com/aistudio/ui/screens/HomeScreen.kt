package com.aistudio.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.aistudio.AppViewModel
import com.aistudio.ui.components.CreditBadge
import com.aistudio.utils.Strings

data class ToolCard(val key: String, val icon: ImageVector, val route: String, val color: Color, val featureKey: String)

val HOME_CARDS = listOf(
    ToolCard("ai_chat", Icons.Default.Chat, "chat", Color(0xFF8B5CF6), "chat"),
    ToolCard("ai_image", Icons.Default.Image, "image", Color(0xFFEC4899), "image"),
    ToolCard("ai_video", Icons.Default.Movie, "video", Color(0xFFEF4444), "video"),
    ToolCard("ai_voice", Icons.Default.Mic, "voice", Color(0xFFF59E0B), "voice"),
    ToolCard("ai_music", Icons.Default.MusicNote, "music", Color(0xFF10B981), "music"),
    ToolCard("ai_writer", Icons.Default.Edit, "writer", Color(0xFF3B82F6), "writer"),
    ToolCard("prompt_generator", Icons.Default.Lightbulb, "prompt", Color(0xFFEAB308), "promptGenerator"),
    ToolCard("my_projects", Icons.Default.Folder, "projects", Color(0xFF64748B), "projects"),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavHostController) {
    val lang = vm.language
    val credits = vm.user?.credits ?: 0
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Hello, ${vm.user?.name?.split(" ")?.firstOrNull() ?: ""} 👋", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("What will you create today?", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
            }
            CreditBadge(credits, lang)
        }
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(HOME_CARDS) { card ->
                val configured = vm.features[card.featureKey] ?: true
                Card(
                    modifier = Modifier
                        .height(130.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable { if (card.route == "projects") nav.navigate("projects") else nav.navigate(card.route) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Box(Modifier.clip(RoundedCornerShape(12.dp)).background(card.color.copy(alpha = 0.15f)).padding(8.dp)) {
                            Icon(card.icon, contentDescription = null, tint = card.color, modifier = Modifier.size(28.dp))
                        }
                        Column {
                            Text(Strings.get(card.key, lang), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            if (!configured && card.featureKey != "projects") {
                                Text("Not configured", fontSize = 10.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

