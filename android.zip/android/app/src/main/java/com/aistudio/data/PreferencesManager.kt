package com.aistudio.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "aistudio_prefs")

class PreferencesManager(private val context: Context) {
    companion object {
        val TOKEN = stringPreferencesKey("jwt_token")
        val LANGUAGE = stringPreferencesKey("language")
    }
    val token: Flow<String?> = context.dataStore.data.map { it[TOKEN] }
    val language: Flow<String> = context.dataStore.data.map { it[LANGUAGE] ?: "en" }
    suspend fun saveToken(token: String?) { context.dataStore.edit { if (token == null) it.remove(TOKEN) else it[TOKEN] = token } }
    suspend fun saveLanguage(lang: String) { context.dataStore.edit { it[LANGUAGE] = lang } }
}
