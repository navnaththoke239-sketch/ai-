import mongoose from 'mongoose';

// Unified generation record: covers image, video, voice(audio), music
const generationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  type: { type: String, enum: ['image', 'video', 'voice', 'music'], required: true, index: true },
  prompt: { type: String, default: '' },
  // Generation params
  aspectRatio: { type: String, default: null },       // 1:1, 16:9, 9:16
  duration: { type: Number, default: null },          // seconds (video/music)
  voiceId: { type: String, default: null },           // voice
  voiceSpeed: { type: Number, default: 1.0 },
  genre: { type: String, default: null },
  mood: { type: String, default: null },
  language: { type: String, enum: ['en', 'hi', 'mr'], default: 'en' },
  // Provider / job tracking
  provider: { type: String, default: 'unknown' },
  providerJobId: { type: String, default: null, index: true },
  status: { type: String, enum: ['pending', 'processing', 'succeeded', 'failed'], default: 'pending', index: true },
  // Result
  resultUrl: { type: String, default: null },         // public/proxied URL of final file
  thumbnailUrl: { type: String, default: null },
  errorMessage: { type: String, default: null },
  creditsUsed: { type: Number, default: 0 },
  projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', default: null, index: true },
  createdAt: { type: Date, default: Date.now, index: true },
  completedAt: { type: Date, default: null },
});

generationSchema.index({ userId: 1, type: 1, createdAt: -1 });

export default mongoose.model('Generation', generationSchema);
