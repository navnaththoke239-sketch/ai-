import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import User from '../models/User.js';
import { signToken } from '../middleware/auth.js';
import { authLimiter } from '../middleware/rateLimit.js';

const router = Router();

// POST /api/auth/signup
router.post('/signup', authLimiter, [
  body('name').trim().isLength({ min: 2, max: 100 }),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6, max: 100 }),
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'Please enter a valid name, email and password (min 6 chars).' });

    const { name, email, password, language } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: 'An account with this email already exists.' });

    const isAdmin = email.toLowerCase() === (process.env.ADMIN_EMAIL || '').toLowerCase();
    const user = await User.create({
      name, email, password,
      language: ['en', 'hi', 'mr'].includes(language) ? language : 'en',
      credits: parseInt(process.env.DEFAULT_FREE_CREDITS || '100', 10),
      isAdmin,
    });
    const token = signToken(user._id);
    res.status(201).json({
      token,
      user: { id: user._id, name: user.name, email: user.email, credits: user.credits, isAdmin: user.isAdmin, language: user.language },
    });
  } catch (err) {
    console.error('[auth/signup]', err);
    res.status(500).json({ error: 'Sign up failed. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', authLimiter, [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 1 }),
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'Please enter your email and password.' });

    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password');
    if (!user) return res.status(401).json({ error: 'Invalid email or password.' });
    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ error: 'Invalid email or password.' });

    user.lastLoginAt = new Date();
    await user.save();
    const token = signToken(user._id);
    res.json({
      token,
      user: { id: user._id, name: user.name, email: user.email, credits: user.credits, isAdmin: user.isAdmin, language: user.language },
    });
  } catch (err) {
    console.error('[auth/login]', err);
    res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// GET /api/auth/me  (refresh profile + credits)
router.get('/me', async (req, res) => {
  // protect middleware runs at mount; req.user set
  const u = req.user;
  res.json({ user: { id: u._id, name: u.name, email: u.email, credits: u.credits, isAdmin: u.isAdmin, language: u.language, avatarUrl: u.avatarUrl } });
});

// PUT /api/auth/me  (update name / language / avatar)
router.put('/me', async (req, res) => {
  const u = req.user;
  if (req.body.name) u.name = String(req.body.name).slice(0, 100);
  if (['en', 'hi', 'mr'].includes(req.body.language)) u.language = req.body.language;
  if (typeof req.body.avatarUrl === 'string') u.avatarUrl = req.body.avatarUrl.slice(0, 500);
  await u.save();
  res.json({ user: { id: u._id, name: u.name, email: u.email, credits: u.credits, isAdmin: u.isAdmin, language: u.language, avatarUrl: u.avatarUrl } });
});

export default router;
