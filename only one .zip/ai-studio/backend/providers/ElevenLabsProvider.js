import fetch from 'node-fetch';
import BaseProvider, { ProviderNotConfiguredError } from './BaseProvider.js';

// ElevenLabs TTS provider: REAL multilingual voice generation.
// Supports English, Hindi, and many other languages with multiple voices.
// Get key: https://elevenlabs.io -> Profile + API key
// Docs: https://elevenlabs.io/docs/api-reference/text-to-speech
export default class ElevenLabsProvider extends BaseProvider {
  constructor() {
    super('elevenlabs');
    this.apiKey = process.env.ELEVENLABS_API_KEY || '';
    this.baseUrl = 'https://api.elevenlabs.io/v1';
    this.configured = !!this.apiKey;
    // Voice presets exposed in the app. Swap voice IDs to match your ElevenLabs account.
    this.voices = [
      { id: '21m00Tcm4TlvDq8ikWAM', name: 'Narrator (Female)', gender: 'female', style: 'narrator' },
      { id: 'IKne3meq5aSn9XLyUdCD', name: 'Narrator (Male)', gender: 'male', style: 'narrator' },
      { id: 'Xb7hH8MSUJpSbSDYk0k2', name: 'Cute (Female)', gender: 'female', style: 'cute' },
      { id: 'pNInz6obpgDQGcFmaJgB', name: 'Energetic (Male)', gender: 'male', style: 'energetic' },
      { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Energetic (Female)', gender: 'female', style: 'energetic' },
      { id: 'VR6AewLTigWG4xSOukaG', name: 'Calm (Male)', gender: 'male', style: 'calm' },
    ];
  }

  listVoices() {
    if (!this.configured) throw new ProviderNotConfiguredError('AI Voice');
    return this.voices;
  }

  async generateVoice(text, opts = {}) {
    if (!this.configured) throw new ProviderNotConfiguredError('AI Voice');
    const voiceId = opts.voiceId || this.voices[0].id;
    const speed = Math.min(Math.max(opts.speed || 1.0, 0.5), 2.0);
    const modelId = 'eleven_multilingual_v2'; // supports Hindi + English + many languages
    const res = await fetch(`${this.baseUrl}/text-to-speech/${voiceId}?output_format=mp3_44100_128`, {
      method: 'POST',
      headers: {
        'xi-api-key': this.apiKey,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: modelId,
        voice_settings: { stability: 0.5, similarity_boost: 0.75, speed },
      }),
      timeout: 60000,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`ElevenLabs TTS failed (${res.status}): ${body.slice(0, 300)}`);
    }
    const buffer = Buffer.from(await res.arrayBuffer());
    return { buffer, mimeType: 'audio/mpeg', extension: 'mp3' };
  }
}
