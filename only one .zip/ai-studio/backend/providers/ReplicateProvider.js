import fetch from 'node-fetch';
import BaseProvider, { ProviderNotConfiguredError, ProviderUnsupportedError } from './BaseProvider.js';

// Replicate provider: REAL video generation (text-to-video & image-to-video)
// and REAL music generation (meta/musicgen).
// Get your token: https://replicate.com/account/api-tokens
//
// Video models used (swap in env if desired):
//   TEXT_TO_VIDEO_MODEL  default: "luma-ai/ray2" (or "anotherjesse/zeroscope-v2-xl")
//   IMAGE_TO_VIDEO_MODEL default: "stability-ai/stable-video-diffusion:3f0457e4619daac51203dedb472816fd4af51f3149fa7a9e0b5ffcf1b8172438"
//   MUSIC_MODEL          default: "meta/musicgen:671ac645ce5e552cc63a54a2bbff63fcf798043055d2dac5fc9e36a837eedcfb"
export default class ReplicateProvider extends BaseProvider {
  constructor() {
    super('replicate');
    this.token = process.env.REPLICATE_API_TOKEN || '';
    this.configured = !!this.token;
    this.textToVideoModel = process.env.REPLICATE_TEXT_TO_VIDEO_MODEL || 'luma-ai/ray2';
    this.imageToVideoModel = process.env.REPLICATE_IMAGE_TO_VIDEO_MODEL || 'stability-ai/stable-video-diffusion:3f0457e4619daac51203dedb472816fd4af51f3149fa7a9e0b5ffcf1b8172438';
    this.musicModel = process.env.REPLICATE_MUSIC_MODEL || 'meta/musicgen:671ac645ce5e552cc63a54a2bbff63fcf798043055d2dac5fc9e36a837eedcfb';
  }

  _headers() {
    return {
      Authorization: `Token ${this.token}`,
      'Content-Type': 'application/json',
      Prefer: 'wait=5', // return after up to 5s if ready, otherwise poll
    };
  }

  // ---- VIDEO ----
  async generateVideo(prompt, opts = {}) {
    if (!this.configured) throw new ProviderNotConfiguredError('Video generation');
    const isImageToVideo = !!opts.imageUrl;
    const model = isImageToVideo ? this.imageToVideoModel : this.textToVideoModel;

    // Map aspect ratio to model params (luma-ai/ray2 uses aspect_ratio; zeroscope uses width/height)
    const aspect = opts.aspectRatio || '9:16';
    const input = isImageToVideo
      ? { image: opts.imageUrl, motion_bucket_id: opts.motion || 127, fps: opts.fps || 15, cond_aug: 0.02 }
      : { prompt, aspect_ratio: aspect, duration: (opts.duration || 5) };

    const res = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: this._headers(),
      body: JSON.stringify({ version: model.includes(':') ? model.split(':')[1] : undefined, model, input }),
      timeout: 30000,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`Replicate video submit failed (${res.status}): ${body.slice(0, 300)}`);
    }
    const data = await res.json();
    return { jobId: data.id, status: this._mapStatus(data.status), raw: data };
  }

  async getVideoStatus(jobId) {
    if (!this.configured) throw new ProviderNotConfiguredError('Video generation');
    const res = await fetch(`https://api.replicate.com/v1/predictions/${jobId}`, {
      headers: { Authorization: `Token ${this.token}` },
      timeout: 30000,
    });
    if (!res.ok) throw new Error(`Replicate status check failed (${res.status})`);
    const data = await res.json();
    const status = this._mapStatus(data.status);
    let videoUrl = null;
    if (status === 'succeeded') {
      // output may be a string URL or an array; pick the .mp4
      const out = data.output;
      videoUrl = Array.isArray(out) ? out.find(u => /\.mp4/i.test(u)) || out[out.length - 1] : out;
    }
    return {
      status,
      videoUrl,
      progress: data.progress || null,
      error: data.error || null,
      logs: data.logs ? data.logs.slice(-500) : null,
    };
  }

  // ---- MUSIC ----
  async generateMusic(prompt, opts = {}) {
    if (!this.configured) throw new ProviderNotConfiguredError('Music generation');
    const res = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: this._headers(),
      body: JSON.stringify({
        model: this.musicModel,
        input: {
          prompt: `${opts.mood ? opts.mood + ', ' : ''}${opts.genre ? opts.genre + ', ' : ''}${prompt}`,
          duration: Math.min(opts.duration || 8, 30),
          model_version: 'stereo-large',
          output_format: 'mp3',
        },
      }),
      timeout: 30000,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`Replicate music submit failed (${res.status}): ${body.slice(0, 300)}`);
    }
    const data = await res.json();
    return { jobId: data.id, status: this._mapStatus(data.status) };
  }

  async getMusicStatus(jobId) {
    if (!this.configured) throw new ProviderNotConfiguredError('Music generation');
    const res = await fetch(`https://api.replicate.com/v1/predictions/${jobId}`, {
      headers: { Authorization: `Token ${this.token}` },
      timeout: 30000,
    });
    if (!res.ok) throw new Error(`Replicate music status failed (${res.status})`);
    const data = await res.json();
    const status = this._mapStatus(data.status);
    const audioUrl = status === 'succeeded' ? (Array.isArray(data.output) ? data.output[0] : data.output) : null;
    return { status, audioUrl, error: data.error || null };
  }

  _mapStatus(s) {
    // Replicate: starting | processing | succeeded | failed | canceled
    if (s === 'succeeded') return 'succeeded';
    if (s === 'failed' || s === 'canceled') return 'failed';
    return 'processing';
  }
}
