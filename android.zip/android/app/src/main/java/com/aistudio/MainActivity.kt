package com.aistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aistudio.data.*
import com.aistudio.ui.theme.AIStudioTheme
import com.aistudio.ui.screens.*
import com.aistudio.utils.Strings
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {
    lateinit var prefs: PreferencesManager
    lateinit var api: ApiService
    var user by mutableStateOf<UserProfile?>(null)
    var token by mutableStateOf<String?>(null)
    var language by mutableStateOf("en")
    var darkMode by mutableStateOf(true)
    var features by mutableStateOf<Map<String, Boolean>>(emptyMap())

    fun init(context: android.content.Context) {
        prefs = PreferencesManager(context)
        api = ApiService.create { token }
        viewModelScope.launch {
            token = prefs.token.first()
            language = prefs.language.first()
            if (!token.isNullOrBlank()) {
                runCatching { val r = api.me(); if (r.isSuccessful) user = r.body()?.user; else token = null }
            }
            runCatching { features = api.status().features }
        }
    }
    fun logout() { viewModelScope.launch { prefs.saveToken(null); token = null; user = null } }
    fun t(key: String) = Strings.get(key, language)
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.init(applicationContext)
        setContent {
            AIStudioTheme(darkTheme = vm.darkMode) {
                Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                    AppRoot(vm)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    if (vm.token.isNullOrBlank()) {
        LoginScreen(vm) { nav.navigate("home") { popUpTo(0) } }
        return
    }
    val items = listOf(
        Triple("home", Icons.Default.Home, "home"),
        Triple("create", Icons.Default.AddCircle, "create"),
        Triple("projects", Icons.Default.Folder, "projects"),
        Triple("history", Icons.Default.History, "history"),
        Triple("profile", Icons.Default.Person, "profile"),
    )
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomNav = currentRoute in items.map { it.first }

    Scaffold(
        bottomBar = {
            if (showBottomNav) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                items.forEach { (route, icon, key) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = { nav.navigate(route) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true } },
                        icon = { Icon(icon, contentDescription = null) },
                        label = { Text(vm.t(key), style = MaterialTheme.typography.labelSmall) },
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") { HomeScreen(vm, nav) }
            composable("create") { CreateScreen(vm, nav) }
            composable("projects") { ProjectsScreen(vm, nav) }
            composable("history") { HistoryScreen(vm) }
            composable("profile") { ProfileScreen(vm) }
            composable("chat") { ChatScreen(vm) }
            composable("image") { ImageScreen(vm) }
            composable("video") { VideoScreen(vm) }
            composable("voice") { VoiceScreen(vm) }
            composable("music") { MusicScreen(vm) }
            composable("writer") { WriterScreen(vm) }
            composable("prompt") { PromptGeneratorScreen(vm) }
        }
    }
}
