package com.aistudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.data.MusicGenRequest
import com.aistudio.ui.components.CreditConfirmDialog
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("Calm") }
    var genre by remember { mutableStateOf("Lo-fi") }
    var duration by remember { mutableStateOf(8) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var audioUrl by remember { mutableStateOf<String?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    val cost = 3 * duration

    fun generate() {
        showConfirm = false; loading = true; error = null; audioUrl = null
        scope.launch {
            runCatching {
                val resp = vm.api.generateMusic(MusicGenRequest(prompt = prompt, mood = mood, genre = genre, duration = duration))
                vm.user = vm.user?.copy(credits = resp.credits)
                val id = resp.generationId
                var attempts = 0
                while (attempts < 60) {
                    delay(4000)
                    val s = vm.api.musicStatus(id)
                    vm.user = vm.user?.copy(credits = s.credits)
                    if (s.status == "succeeded" && s.audioUrl != null) { audioUrl = s.audioUrl; loading = false; return@launch }
                    if (s.status == "failed") { error = s.error ?: Strings.get("gen_failed", lang); loading = false; return@launch }
                    attempts++
                }
                error = "Music generation taking too long. Check History."; loading = false
            }.onFailure { error = friendlyError(it.message, lang); loading = false }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("ai_music", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Describe the music…") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4)
            Spacer(Modifier.height(12.dp))
            Text(Strings.get("mood", lang), style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Calm", "Energetic", "Sad", "Happy", "Epic").forEach { FilterChip(selected = mood == it, onClick = { mood = it }, label = { Text(it) }) }
            }
            Spacer(Modifier.height(8.dp))
            Text(Strings.get("genre", lang), style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Lo-fi", "Hip-hop", "Electronic", "Orchestral", "Pop").forEach { FilterChip(selected = genre == it, onClick = { genre = it }, label = { Text(it) }) }
            }
            Spacer(Modifier.height(8.dp))
            Text("${Strings.get("duration", lang)}: $duration ${Strings.get("seconds", lang)}", style = MaterialTheme.typography.labelMedium)
            Slider(value = duration.toFloat(), onValueChange = { duration = it.toInt() }, valueRange = 2f..30f, steps = 27)
            Spacer(Modifier.height(16.dp))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            if (loading) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { CircularProgressIndicator(); Spacer(Modifier.height(8.dp)); Text(Strings.get("generating", lang)) } }
            else PrimaryButton(Strings.get("generate", lang), onClick = { showConfirm = true }, enabled = prompt.isNotBlank())

            audioUrl?.let { url ->
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Music ready", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { android.media.MediaPlayer().apply { setDataSource(url); prepare(); start() } }) { Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("preview", lang)) }
                            OutlinedButton(onClick = { downloadFile(ctx, url, "mp3") }) { Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("download", lang)) }
                            OutlinedButton(onClick = { shareFile(ctx, url) }) { Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("share", lang)) }
                        }
                    }
                }
            }
        }
    }
    if (showConfirm) CreditConfirmDialog(cost, lang, onConfirm = { generate() }, onDismiss = { showConfirm = false })
}
