package com.aistudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.data.WriterRequest
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

val WRITER_TOOLS = listOf(
    "youtube_shorts" to "YouTube Shorts Script",
    "youtube_title" to "YouTube Titles",
    "youtube_description" to "YouTube Description",
    "caption" to "Captions",
    "story" to "Story",
    "dialogue" to "Dialogue",
    "anime_story" to "Anime Story",
    "funny_script" to "Funny Script",
    "voiceover" to "Voice-over Script",
    "translation" to "Translate Text",
    "rewrite" to "Rewrite Text",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WriterScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var category by remember { mutableStateOf("youtube_shorts") }
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("ai_writer", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(value = WRITER_TOOLS.first { it.first == category }.second, onValueChange = {}, readOnly = true, label = { Text("Tool") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.fillMaxWidth().menuAnchor())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    WRITER_TOOLS.forEach { (key, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { category = key; expanded = false }) }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Topic / text to process…") }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
            Spacer(Modifier.height(16.dp))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            PrimaryButton(Strings.get("generate", lang), onClick = {
                error = null; loading = true; output = null
                scope.launch {
                    runCatching {
                        val resp = vm.api.writerGenerate(WriterRequest(category = category, inputText = input, language = lang))
                        vm.user = vm.user?.copy(credits = resp.credits); output = resp.output
                    }.onFailure { error = friendlyError(it.message, lang) }
                    loading = false
                }
            }, enabled = input.isNotBlank() && !loading, loading = loading)

            output?.let { text ->
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Result", style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { copyText(ctx, text) }) { Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("copy", lang)) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(text, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
