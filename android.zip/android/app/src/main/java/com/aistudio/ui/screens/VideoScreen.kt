package com.aistudio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.aistudio.AppViewModel
import com.aistudio.data.VideoGenRequest
import com.aistudio.ui.components.CreditConfirmDialog
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var prompt by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var aspect by remember { mutableStateOf("9:16") }
    var duration by remember { mutableStateOf(5) }
    var loading by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var videoUrl by remember { mutableStateOf<String?>(null) }
    var generationId by remember { mutableStateOf<String?>(null) }
    var showConfirm by remember { mutableStateOf(false) }
    val cost = 5 * duration // matches backend video_per_second=5

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> imageUri = uri }

    // ExoPlayer for REAL video playback
    val exoPlayer = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(videoUrl) {
        if (videoUrl != null) {
            exoPlayer.setMediaItem(MediaItem.fromUri(videoUrl!!))
            exoPlayer.prepare()
        }
        onDispose { exoPlayer.release() }
    }

    fun startGeneration() {
        showConfirm = false; loading = true; error = null; videoUrl = null
        progressText = Strings.get("generating_video", lang)
        scope.launch {
            runCatching {
                // 1. Submit job to backend -> real provider (Replicate etc.)
                val resp = vm.api.generateVideo(VideoGenRequest(
                    prompt = prompt.ifBlank { "animate this image" },
                    aspectRatio = aspect, duration = duration,
                    imageUrl = imageUri?.toString(), // in production, upload to storage first
                ))
                generationId = resp.generationId
                vm.user = vm.user?.copy(credits = resp.credits)
                // 2. Poll status until succeeded/failed (async job model)
                val pollId = resp.generationId
                var attempts = 0
                while (attempts < 120) { // up to ~10 min (5s interval)
                    delay(5000)
                    val s = vm.api.videoStatus(pollId)
                    vm.user = vm.user?.copy(credits = s.credits)
                    if (s.status == "succeeded" && s.videoUrl != null) {
                        videoUrl = s.videoUrl; loading = false; return@launch
                    }
                    if (s.status == "failed") {
                        error = s.error ?: Strings.get("gen_failed", lang); loading = false; return@launch
                    }
                    progressText = "${Strings.get("generating_video", lang)} ${s.progress ?: ""}"
                    attempts++
                }
                error = "Generation is taking longer than expected. Check History tab."; loading = false
            }.onFailure { error = friendlyError(it.message, lang); loading = false }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("ai_video", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            if (videoUrl != null) {
                // REAL video player — no placeholders
                AndroidView(
                    factory = { PlayerView(ctx).apply { player = exoPlayer; useController = true } },
                    modifier = Modifier.fillMaxWidth().aspectRatio(when (aspect) { "16:9" -> 16f/9; "1:1" -> 1f; else -> 9f/16 }).clip(RoundedCornerShape(12.dp)),
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { downloadFile(ctx, videoUrl!!, "mp4") }) { Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("download", lang)) }
                    OutlinedButton(onClick = { shareFile(ctx, videoUrl!!) }) { Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("share", lang)) }
                    OutlinedButton(onClick = { startGeneration() }) { Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("regenerate", lang)) }
                    OutlinedButton(onClick = { scope.launch { generationId?.let { runCatching { vm.api.deleteVideo(it) } }; videoUrl = null } }) { Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error); Spacer(Modifier.width(4.dp)); Text(Strings.get("delete", lang), color = MaterialTheme.colorScheme.error) }
                }
                Spacer(Modifier.height(16.dp))
            }

            if (loading) {
                Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(16.dp))
                        Text(progressText, style = MaterialTheme.typography.bodyMedium)
                        Text("This may take 1–5 minutes. Please keep the app open.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    }
                }
            } else {
                OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text(Strings.get("animation_instructions", lang)) }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 5)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { pickImage.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Image, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(8.dp))
                    Text(if (imageUri != null) "Image selected ✓" else Strings.get("upload_image", lang))
                }
                Spacer(Modifier.height(12.dp))
                Text(Strings.get("aspect_ratio", lang), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("9:16" to "Vertical", "16:9" to "Landscape", "1:1" to "Square").forEach { (ratio, label) ->
                        FilterChip(selected = aspect == ratio, onClick = { aspect = ratio }, label = { Text("$ratio $label") })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("${Strings.get("duration", lang)}: $duration ${Strings.get("seconds", lang)}", style = MaterialTheme.typography.labelMedium)
                Slider(value = duration.toFloat(), onValueChange = { duration = it.toInt() }, valueRange = 3f..15f, steps = 11)
                Spacer(Modifier.height(16.dp))
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                PrimaryButton(Strings.get("generate", lang), onClick = { showConfirm = true }, enabled = prompt.isNotBlank() || imageUri != null)
            }
        }
    }
    if (showConfirm) CreditConfirmDialog(cost, lang, onConfirm = { startGeneration() }, onDismiss = { showConfirm = false })
}
