import fetch from 'node-fetch';
import BaseProvider, { ProviderNotConfiguredError } from './BaseProvider.js';

// OpenAI-compatible provider: chat + DALL-E image generation.
// Also works with Azure OpenAI, OpenRouter, Together, Groq, etc. via OPENAI_BASE_URL.
export default class OpenAIProvider extends BaseProvider {
  constructor() {
    super('openai');
    this.apiKey = process.env.OPENAI_API_KEY || '';
    this.baseUrl = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
    this.chatModel = process.env.OPENAI_CHAT_MODEL || 'gpt-4o-mini';
    this.configured = !!this.apiKey;
  }

  _headers() {
    return { 'Content-Type': 'application/json', Authorization: `Bearer ${this.apiKey}` };
  }

  async chat(messages, opts = {}) {
    if (!this.configured) throw new ProviderNotConfiguredError('AI Chat');
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: this._headers(),
      body: JSON.stringify({
        model: opts.model || this.chatModel,
        messages,
        temperature: opts.temperature ?? 0.7,
        max_tokens: opts.max_tokens ?? 1200,
      }),
      timeout: 60000,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`OpenAI chat failed (${res.status}): ${body.slice(0, 300)}`);
    }
    const data = await res.json();
    return data.choices?.[0]?.message?.content || '';
  }

  async generateImage(prompt, opts = {}) {
    if (!this.configured) throw new ProviderNotConfiguredError('AI Image');
    const sizeMap = { '1:1': '1024x1024', '16:9': '1792x1024', '9:16': '1024x1792' };
    const n = Math.min(opts.count || 1, 4);
    const res = await fetch(`${this.baseUrl}/images/generations`, {
      method: 'POST',
      headers: this._headers(),
      body: JSON.stringify({
        model: 'dall-e-3',
        prompt,
        n: 1, // dall-e-3 only supports n=1; loop for multiple
        size: sizeMap[opts.aspectRatio || '1:1'] || '1024x1024',
        quality: opts.quality || 'standard',
      }),
      timeout: 120000,
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`OpenAI image failed (${res.status}): ${body.slice(0, 300)}`);
    }
    const data = await res.json();
    const urls = [];
    for (let i = 0; i < n; i++) {
      if (i === 0) {
        urls.push(data.data?.[0]?.url);
      } else {
        // dall-e-3 n=1 only; fire extra requests for additional images
        const r2 = await fetch(`${this.baseUrl}/images/generations`, {
          method: 'POST', headers: this._headers(),
          body: JSON.stringify({ model: 'dall-e-3', prompt, n: 1, size: sizeMap[opts.aspectRatio || '1:1'] || '1024x1024' }),
        });
        if (r2.ok) {
          const d2 = await r2.json();
          urls.push(d2.data?.[0]?.url);
        }
      }
    }
    return urls.filter(Boolean);
  }
}
