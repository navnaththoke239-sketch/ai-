package com.aistudio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Modern professional AI app palette — dark by default
val PurpleAccent = Color(0xFF8B5CF6)
val CyanAccent = Color(0xFF22D3EE)
val DarkBg = Color(0xFF0B0F1A)
val DarkSurface = Color(0xFF141A2E)
val DarkCard = Color(0xFF1A2138)

private val DarkColors = darkColorScheme(
    primary = PurpleAccent,
    secondary = CyanAccent,
    background = DarkBg,
    surface = DarkSurface,
    surfaceVariant = DarkCard,
    onPrimary = Color.White,
    onBackground = Color(0xFFE6E9F2),
    onSurface = Color(0xFFE6E9F2),
    error = Color(0xFFF87171),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF7C3AED),
    secondary = Color(0xFF0891B2),
    background = Color(0xFFF7F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF0F7),
    onPrimary = Color.White,
    onBackground = Color(0xFF1A1F2E),
    onSurface = Color(0xFF1A1F2E),
)

@Composable
fun AIStudioTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    // Dark mode by default; user can toggle in Profile
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = MaterialTheme.typography, content = content)
}
