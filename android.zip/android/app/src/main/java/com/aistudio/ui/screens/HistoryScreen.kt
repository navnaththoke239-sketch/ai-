package com.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aistudio.AppViewModel
import com.aistudio.data.GenerationRecord
import com.aistudio.data.ScriptRecord
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var gens by remember { mutableStateOf<List<GenerationRecord>>(emptyList()) }
    var scripts by remember { mutableStateOf<List<ScriptRecord>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) { scope.launch { runCatching { val h = vm.api.history(); gens = h.generations; scripts = h.scripts }; loading = false } }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("history", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Media") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Scripts") })
            }
            if (loading) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            else if (tab == 0) {
                LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (gens.isEmpty()) item { Text("No generations yet.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)) }
                    items(gens) { g ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (g.type == "image" && g.resultUrl != null) {
                                    AsyncImage(model = g.resultUrl, contentDescription = null, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)))
                                } else {
                                    Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                                        Icon(when (g.type) { "video" -> Icons.Default.Movie; "voice" -> Icons.Default.Mic; "music" -> Icons.Default.MusicNote; else -> Icons.Default.Image }, null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(g.type.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleSmall)
                                    Text(g.prompt.take(60), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f), maxLines = 1)
                                    Text("${g.creditsUsed} credits · ${g.status}", style = MaterialTheme.typography.labelSmall, color = if (g.status == "succeeded") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                }
                                if (g.resultUrl != null) IconButton(onClick = { shareFile(ctx, g.resultUrl!!) }) { Icon(Icons.Default.Share, null, modifier = Modifier.size(18.dp)) }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (scripts.isEmpty()) item { Text("No scripts yet.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)) }
                    items(scripts) { s ->
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))) {
                            Column(Modifier.padding(12.dp)) {
                                Text(s.category.replace("_", " ").replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleSmall)
                                Text(s.outputText.take(120), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f), maxLines = 3)
                            }
                        }
                    }
                }
            }
        }
    }
}

