package com.aistudio.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aistudio.AppViewModel
import com.aistudio.data.ChatMessage
import com.aistudio.data.ChatSendRequest
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var chatId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun send() {
        if (input.isBlank() || loading) return
        val userMsg = ChatMessage("user", input.trim(), lang)
        val newList = messages + userMsg
        messages = newList
        val prompt = input.trim()
        input = ""; error = null; loading = true
        scope.launch {
            runCatching {
                val resp = vm.api.chatSend(ChatSendRequest(chatId = chatId, messages = newList, language = lang))
                chatId = resp.chatId
                vm.user = vm.user?.copy(credits = resp.credits)
                messages = messages + ChatMessage("assistant", resp.reply, lang)
            }.onFailure { error = friendlyError(it.message, lang) }
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Strings.get("ai_chat", lang)) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                actions = {
                    IconButton(onClick = { messages = emptyList(); chatId = null; error = null }) { Icon(Icons.Default.Add, contentDescription = Strings.get("new_chat", lang)) }
                },
            )
        },
        bottomBar = {
            Column(Modifier.padding(12.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp)) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text(Strings.get("enter_prompt", lang)) }, maxLines = 4)
                    Spacer(Modifier.width(8.dp))
                    if (loading) {
                        IconButton(onClick = { /* stop: best-effort; backend job not cancellable in this version */ loading = false }) { Icon(Icons.Default.Stop, contentDescription = Strings.get("stop", lang), tint = MaterialTheme.colorScheme.error) }
                    } else {
                        FilledIconButton(onClick = { send() }) { Icon(Icons.Default.Send, contentDescription = null) }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), reverseLayout = false) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(msg.content, color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground, fontSize = 14.sp)
                        if (!isUser) {
                            Spacer(Modifier.height(4.dp))
                            Row {
                                TextButton(onClick = { copyText(ctx, msg.content) }, contentPadding = PaddingValues(4.dp)) { Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(2.dp)); Text(Strings.get("copy", lang), fontSize = 11.sp) }
                                TextButton(onClick = { input = msg.content; send() }, contentPadding = PaddingValues(4.dp)) { Icon(Icons.Default.Refresh, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(2.dp)); Text(Strings.get("regenerate", lang), fontSize = 11.sp) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            if (loading) item { Row { CircularProgressIndicator(modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text(Strings.get("generating", lang)) } }
        }
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("AI Studio", text))
}

fun friendlyError(msg: String?, lang: String): String {
    msg ?: return Strings.get("gen_failed", lang)
    return when {
        msg.contains("402") || msg.contains("insufficient", true) -> Strings.get("insufficient_credits", lang)
        msg.contains("429") || msg.contains("busy", true) -> Strings.get("server_busy", lang)
        msg.contains("503") || msg.contains("not configured", true) -> msg
        else -> Strings.get("gen_failed", lang)
    }
}
