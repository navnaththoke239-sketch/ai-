# AI Studio

All-in-one AI Android app: chat, image, video, voice, music, writer, prompt generator — with a secure backend, credits system, projects, and admin panel. Dark mode, English/Hindi/Marathi, beginner-friendly.

**No fake buttons, no fake AI responses, no placeholder videos.** Every generation calls a real AI provider through the secure backend. If a provider isn't configured, the app shows a clear "not configured" message.

## Quick start
```bash
# 1. Backend
cd backend && cp .env.example .env   # add your API keys + MongoDB URI
npm install && npm run dev           # http://localhost:5000  (admin at /admin)

# 2. Android
# Open android/ in Android Studio, set BASE_URL in app/build.gradle.kts, run.
```

See **SETUP.md** for full instructions: backend config, API key locations, database, APK build, testing each feature, secure deployment, and provider architecture.

## Architecture
```
Android (Kotlin + Jetpack Compose)
   │  HTTPS + JWT, no API keys in APK
   ▼
Backend (Node.js + Express + MongoDB)
   ├── Auth (JWT, bcrypt, rate limiting)
   ├── Credits (deduct before generate, refund on failure)
   └── ProviderFactory → OpenAI · Replicate (video+music) · ElevenLabs (voice)
                          └─ extend BaseProvider to add any provider
```

## Video generation (real, no fakes)
`POST /api/video/generate` → async job → `GET /api/video/status/{id}` polled by app → real `.mp4` played in ExoPlayer → Download / Share / Regenerate / Delete. See SETUP.md §2.
