package com.aistudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.data.PromptRequest
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

val PROMPT_TYPES = listOf(
    "prompt_image" to "Image Prompt",
    "prompt_video" to "Video Prompt",
    "prompt_anime" to "Anime Prompt",
    "prompt_cat" to "Cat / Funny Video Prompt",
    "prompt_youtube" to "YouTube Prompt",
    "prompt_voice" to "Voice Prompt",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptGeneratorScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var type by remember { mutableStateOf("prompt_image") }
    var idea by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("prompt_generator", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Prompt type", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            PROMPT_TYPES.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (key, label) -> FilterChip(selected = type == key, onClick = { type = key }, label = { Text(label) }, modifier = Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = idea, onValueChange = { idea = it }, label = { Text("Your short idea…") }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4)
            Spacer(Modifier.height(16.dp))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            PrimaryButton("Generate detailed prompt", onClick = {
                error = null; loading = true; result = null
                scope.launch {
                    runCatching {
                        val resp = vm.api.promptGenerate(PromptRequest(type = type, idea = idea, language = lang))
                        vm.user = vm.user?.copy(credits = resp.credits); result = resp.prompt
                    }.onFailure { error = friendlyError(it.message, lang) }
                    loading = false
                }
            }, enabled = idea.isNotBlank() && !loading, loading = loading)

            result?.let { text ->
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Copy-ready prompt", style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { copyText(ctx, text) }) { Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(Strings.get("copy", lang)) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(text, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
