package com.aistudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.ui.components.CreditBadge
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(vm: AppViewModel) {
    val lang = vm.language
    val scope = rememberCoroutineScope()
    val user = vm.user

    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(80.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Text(user?.name?.firstOrNull()?.uppercase() ?: "U", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(12.dp))
        Text(user?.name ?: "", style = MaterialTheme.typography.titleLarge)
        Text(user?.email ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(12.dp))
        CreditBadge(user?.credits ?: 0, lang)
        Spacer(Modifier.height(24.dp))

        // Language selector
        Text(Strings.get("language", lang), style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("en" to "English", "hi" to "हिन्दी", "mr" to "मराठी").forEach { (code, label) ->
                FilterChip(selected = vm.language == code, onClick = { vm.language = code; scope.launch { vm.prefs.saveLanguage(code) } }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(16.dp))

        // Dark mode toggle
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(Strings.get("dark_mode", lang))
            Switch(checked = vm.darkMode, onCheckedChange = { vm.darkMode = it })
        }
        Spacer(Modifier.height(8.dp))
        if (user?.isAdmin == true) {
            OutlinedButton(onClick = { /* open admin URL in browser */ }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Open Admin Panel")
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = { vm.logout() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Logout, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(Strings.get("logout", lang))
        }
    }
}

