package com.aistudio.utils

// Lightweight i18n: English, Hindi, Marathi. No external lib needed.
object Strings {
    private val map = mapOf(
        "app_name" to Triple("AI Studio", "AI स्टूडियो", "AI स्टुडिओ"),
        "remaining_credits" to Triple("Remaining Credits", "शेष क्रेडिट", "उर्वरित क्रेडिट"),
        "generate" to Triple("Generate", "जनरेट करें", "जनरेट करा"),
        "generating" to Triple("Generating…", "जनरेट हो रहा है…", "जनरेट होत आहे…"),
        "generating_video" to Triple("Generating video…", "वीडियो जनरेट हो रहा है…", "व्हिडिओ जनरेट होत आहे…"),
        "enter_prompt" to Triple("Enter your prompt…", "अपना प्रॉम्प्ट लिखें…", "तुमचा प्रॉम्प्ट लिहा…"),
        "new_chat" to Triple("New Chat", "नई चैट", "नवीन चॅट"),
        "copy" to Triple("Copy", "कॉपी", "कॉपी"),
        "regenerate" to Triple("Regenerate", "फिर से जनरेट", "पुन्हा जनरेट"),
        "stop" to Triple("Stop", "रोकें", "थांबवा"),
        "download" to Triple("Download", "डाउनलोड", "डाउनलोड"),
        "share" to Triple("Share", "शेयर", "शेअर"),
        "delete" to Triple("Delete", "हटाएं", "हटवा"),
        "enhance" to Triple("Enhance", "बेहतर बनाएं", "सुधारा"),
        "preview" to Triple("Preview", "पूर्वावलोकन", "पूर्वावलोकन"),
        "aspect_ratio" to Triple("Aspect Ratio", "एस्पेक्ट रेशियो", "अस्पेक्ट रेशिओ"),
        "duration" to Triple("Duration", "अवधि", "कालावधी"),
        "seconds" to Triple("seconds", "सेकंड", "सेकंद"),
        "upload_image" to Triple("Upload image (optional)", "छवि अपलोड करें (वैकल्पिक)", "प्रतिमा अपलोड करा (पर्यायी)"),
        "animation_instructions" to Triple("Animation instructions / prompt", "एनिमेशन निर्देश / प्रॉम्प्ट", "अॅनिमेशन सूचना / प्रॉम्प्ट"),
        "select_voice" to Triple("Select voice", "आवाज़ चुनें", "आवाज निवडा"),
        "speed" to Triple("Speed", "गति", "गती"),
        "enter_text" to Triple("Enter text…", "टेक्स्ट लिखें…", "मजकूर लिहा…"),
        "mood" to Triple("Mood", "मूड", "मूड"),
        "genre" to Triple("Genre", "शैली", "शैली"),
        "my_projects" to Triple("My Projects", "मेरी प्रोजेक्ट", "माझे प्रोजेक्ट"),
        "create_project" to Triple("Create Project", "प्रोजेक्ट बनाएं", "प्रोजेक्ट तयार करा"),
        "rename" to Triple("Rename", "नाम बदलें", "नाव बदला"),
        "logout" to Triple("Logout", "लॉगआउट", "लॉगआउट"),
        "login" to Triple("Login", "लॉगिन", "लॉगिन"),
        "signup" to Triple("Sign Up", "साइन अप", "साइन अप"),
        "email" to Triple("Email", "ईमेल", "ईमेल"),
        "password" to Triple("Password", "पासवर्ड", "पासवर्ड"),
        "name" to Triple("Name", "नाम", "नाव"),
        "home" to Triple("Home", "होम", "होम"),
        "create" to Triple("Create", "बनाएं", "तयार करा"),
        "projects" to Triple("Projects", "प्रोजेक्ट", "प्रोजेक्ट"),
        "history" to Triple("History", "इतिहास", "इतिहास"),
        "profile" to Triple("Profile", "प्रोफाइल", "प्रोफाइल"),
        "ai_chat" to Triple("AI Chat", "AI चैट", "AI चॅट"),
        "ai_image" to Triple("AI Image", "AI इमेज", "AI इमेज"),
        "ai_video" to Triple("AI Video", "AI वीडियो", "AI व्हिडिओ"),
        "ai_voice" to Triple("AI Voice", "AI आवाज़", "AI आवाज"),
        "ai_music" to Triple("AI Music", "AI संगीत", "AI संगीत"),
        "ai_writer" to Triple("AI Writer", "AI राइटर", "AI राइटर"),
        "prompt_generator" to Triple("Prompt Generator", "प्रॉम्प्ट जनरेटर", "प्रॉम्प्ट जनरेटर"),
        "will_cost" to Triple("This will use ~%d credits. Continue?", "इसमें ~%d क्रेडिट लगेंगे। जारी रखें?", "यात ~%d क्रेडिट लागतील. सुरू ठेवायचे?"),
        "insufficient_credits" to Triple("Your credits are insufficient.", "आपके क्रेडिट कमी हैं।", "तुमचे क्रेडिट अपुरे आहेत."),
        "gen_failed" to Triple("Generation failed. Please try again.", "जनरेशन विफल। कृपया पुनः प्रयास करें।", "जनरेशन अयशस्वी. कृपया पुन्हा प्रयत्न करा."),
        "server_busy" to Triple("Server is busy. Please try again later.", "सर्वर व्यस्त है। बाद में प्रयास करें।", "सर्व्हर व्यस्त आहे. नंतर प्रयत्न करा."),
        "not_configured" to Triple("%s is not configured yet. Please connect a supported AI provider in the backend.", "%s अभी कॉन्फ़िगर नहीं है। कृपया बैकएंड में AI प्रोवाइडर जोड़ें।", "%s अद्याप कॉन्फिगर केलेले नाही. कृपया बॅकएंडमध्ये AI प्रोव्हायडर जोडा."),
        "choose_tool" to Triple("Choose a tool", "टूल चुनें", "टूल निवडा"),
        "language" to Triple("Language", "भाषा", "भाषा"),
        "dark_mode" to Triple("Dark Mode", "डार्क मोड", "डार्क मोड"),
        "copied" to Triple("Copied!", "कॉपी हो गया!", "कॉपी झाले!"),
        "saved" to Triple("Saved", "सेव हो गया", "सेव्ह झाले"),
    )

    fun get(key: String, lang: String): String {
        val t = map[key] ?: return key
        return when (lang) {
            "hi" -> t.second
            "mr" -> t.third
            else -> t.first
        }
    }
    fun format(key: String, lang: String, vararg args: Any?): String =
        String.format(get(key, lang), *args)
}
