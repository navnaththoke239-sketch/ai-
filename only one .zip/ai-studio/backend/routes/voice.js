import { Router } from 'express';
import Generation from '../models/Generation.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';
import { generationLimiter } from '../middleware/rateLimit.js';

const router = Router();

// GET /api/voice/voices — list available voices
router.get('/voices', (req, res) => {
  try {
    const provider = ProviderFactory.getVoiceProvider();
    res.json({ voices: provider.listVoices() });
  } catch (err) {
    if (err instanceof ProviderNotConfiguredError) {
      return res.status(503).json({ error: 'AI Voice is not configured yet. Please connect a supported TTS provider in the backend.' });
    }
    res.status(500).json({ error: 'Could not load voices.' });
  }
});

// POST /api/voice/generate — returns audio file directly (synchronous TTS)
// Body: { text, voiceId, speed (0.5-2), language, projectId? }
router.post('/generate', generationLimiter, async (req, res) => {
  try {
    const { text, voiceId, speed, language, projectId } = req.body;
    if (!text || !String(text).trim()) return res.status(400).json({ error: 'Please enter text to speak.' });
    const cleanText = String(text).slice(0, 3000);

    const cost = estimateCost('voice', { text: cleanText });
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    let audio;
    try {
      const provider = ProviderFactory.getVoiceProvider();
      audio = await provider.generateVoice(cleanText, { voiceId, speed: parseFloat(speed) || 1.0, language });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: 'AI Voice is not configured yet. Please connect a supported TTS provider in the backend.' });
      console.error('[voice]', err);
      return res.status(502).json({ error: 'Voice generation failed. Please try again.' });
    }

    // Store metadata; audio is returned directly in response (base64 or proxy)
    const rec = await Generation.create({
      userId: req.user._id, type: 'voice', prompt: cleanText.slice(0, 200),
      voiceId, voiceSpeed: parseFloat(speed) || 1.0, language: language || 'en',
      provider: 'elevenlabs', status: 'succeeded', creditsUsed: cost,
      projectId: projectId || null, completedAt: new Date(),
    });

    // Return as base64 data URL so the app can play + save immediately.
    // For production, upload to storage and return a URL instead.
    const b64 = audio.buffer.toString('base64');
    res.json({
      id: rec._id,
      audioDataUrl: `data:${audio.mimeType};base64,${b64}`,
      mimeType: audio.mimeType,
      extension: audio.extension,
      credits: remaining, creditsUsed: cost,
    });
  } catch (err) {
    console.error('[voice]', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

export default router;
