import OpenAIProvider from './OpenAIProvider.js';
import ReplicateProvider from './ReplicateProvider.js';
import ElevenLabsProvider from './ElevenLabsProvider.js';
import { ProviderNotConfiguredError } from './BaseProvider.js';

// ProviderFactory: central place to wire real AI providers.
// The Android app never knows which provider is used — it only calls
// feature endpoints (/api/chat, /api/video/generate, ...).
// To swap a provider, change the mapping here or add a new adapter class.

class ProviderFactory {
  constructor() {
    this.openai = new OpenAIProvider();
    this.replicate = new ReplicateProvider();
    this.elevenlabs = new ElevenLabsProvider();
  }

  // Chat / writer / prompt generator -> OpenAI-compatible
  getChatProvider() {
    if (this.openai.configured) return this.openai;
    throw new ProviderNotConfiguredError('AI Chat');
  }

  // Image -> OpenAI DALL-E (add Stability adapter here if preferred)
  getImageProvider() {
    if (this.openai.configured) return this.openai;
    throw new ProviderNotConfiguredError('AI Image');
  }

  // Video -> Replicate (real text-to-video + image-to-video, async job)
  getVideoProvider() {
    if (this.replicate.configured) return this.replicate;
    throw new ProviderNotConfiguredError('Video generation');
  }

  // Voice -> ElevenLabs (multilingual: Hindi, English, ...)
  getVoiceProvider() {
    if (this.elevenlabs.configured) return this.elevenlabs;
    throw new ProviderNotConfiguredError('AI Voice');
  }

  // Music -> Replicate (meta/musicgen)
  getMusicProvider() {
    if (this.replicate.configured) return this.replicate;
    throw new ProviderNotConfiguredError('Music generation');
  }

  // Report which features are configured (used by /api/status so the app
  // can show "coming soon / not configured" badges without trying to generate)
  getStatus() {
    return {
      chat: this.openai.configured,
      image: this.openai.configured,
      video: this.replicate.configured,
      voice: this.elevenlabs.configured,
      music: this.replicate.configured,
      writer: this.openai.configured,
      promptGenerator: this.openai.configured,
    };
  }
}

export default new ProviderFactory();
