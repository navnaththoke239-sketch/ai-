package com.aistudio.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aistudio.AppViewModel
import com.aistudio.data.ImageGenRequest
import com.aistudio.ui.components.CreditConfirmDialog
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch
import java.io.File
import java.net.URL

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageScreen(vm: AppViewModel) {
    val lang = vm.language
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var aspect by remember { mutableStateOf("1:1") }
    var count by remember { mutableStateOf(1) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var images by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) } // id to url
    var showConfirm by remember { mutableStateOf(false) }
    val cost = 10 * count

    fun generate() {
        showConfirm = false; loading = true; error = null
        scope.launch {
            runCatching {
                val resp = vm.api.generateImage(ImageGenRequest(prompt = prompt, aspectRatio = aspect, count = count))
                vm.user = vm.user?.copy(credits = resp.credits)
                images = resp.images.map { it.id to it.url }
            }.onFailure { error = friendlyError(it.message, lang) }
            loading = false
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(Strings.get("ai_image", lang)) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text(Strings.get("enter_prompt", lang)) }, modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4)
            Spacer(Modifier.height(12.dp))
            Text(Strings.get("aspect_ratio", lang), style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1:1", "16:9", "9:16").forEach { FilterChip(selected = aspect == it, onClick = { aspect = it }, label = { Text(it) }) }
            }
            Spacer(Modifier.height(8.dp))
            Text("Count: $count", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 4).forEach { FilterChip(selected = count == it, onClick = { count = it }, label = { Text("$it") }) }
            }
            Spacer(Modifier.height(16.dp))
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            PrimaryButton(Strings.get("generate", lang), onClick = { showConfirm = true }, enabled = prompt.isNotBlank() && !loading, loading = loading)

            if (images.isNotEmpty()) {
                Spacer(Modifier.height(20.dp))
                Text("Results", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(images) { (id, url) ->
                        Column(Modifier.width(220.dp)) {
                            AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)))
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(onClick = { downloadFile(ctx, url, "png") }, contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.Download, null, modifier = Modifier.size(14.dp)) }
                                OutlinedButton(onClick = { shareFile(ctx, url) }, contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.Share, null, modifier = Modifier.size(14.dp)) }
                                OutlinedButton(onClick = { scope.launch { runCatching { vm.api.deleteImage(id) }; images = images.filterNot { it.first == id } } }, contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.Delete, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error) }
                                OutlinedButton(onClick = { scope.launch { runCatching { val r = vm.api.enhanceImage(mapOf("imageUrl" to url)); images = images + (r.images.first().id to r.images.first().url) } } }, contentPadding = PaddingValues(6.dp)) { Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(14.dp)) }
                            }
                        }
                    }
                }
            }
        }
    }
    if (showConfirm) CreditConfirmDialog(cost, lang, onConfirm = { generate() }, onDismiss = { showConfirm = false })
}

// ---- Shared download/share helpers (used by image/video/music/voice) ----
fun downloadFile(ctx: Context, url: String, ext: String) {
    kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
            val bytes = URL(url).readBytes()
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
            val file = File(dir, "aistudio_${System.currentTimeMillis()}.$ext")
            file.writeBytes(bytes)
            // Also add to public Downloads via MediaStore in production.
            android.widget.Toast.makeText(ctx, "Saved to ${file.absolutePath}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

fun shareFile(ctx: Context, url: String) {
    // In production: download to cache, get FileProvider URI, then ACTION_SEND.
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, url)
    }
    ctx.startActivity(Intent.createChooser(intent, "Share via"))
}
