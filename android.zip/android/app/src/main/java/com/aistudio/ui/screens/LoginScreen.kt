package com.aistudio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.aistudio.AppViewModel
import com.aistudio.data.AuthRequest
import com.aistudio.ui.components.PrimaryButton
import com.aistudio.utils.Strings
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(vm: AppViewModel, onLoggedIn: () -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val lang = vm.language

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("AI Studio", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(4.dp))
        Text("Chat · Image · Video · Voice · Music · Writer", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(32.dp))

        // Language picker
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("en" to "English", "hi" to "हिन्दी", "mr" to "मराठी").forEach { (code, label) ->
                FilterChip(selected = vm.language == code, onClick = { vm.language = code; scope.launch { vm.prefs.saveLanguage(code) } }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(24.dp))

        if (!isLogin) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(Strings.get("name", lang)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text(Strings.get("email", lang)) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(Strings.get("password", lang)) }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(8.dp))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        Spacer(Modifier.height(16.dp))

        PrimaryButton(if (isLogin) Strings.get("login", lang) else Strings.get("signup", lang), onClick = {
            error = null; loading = true
            scope.launch {
                runCatching {
                    val resp = if (isLogin) vm.api.login(AuthRequest(email = email, password = password))
                    else vm.api.signup(AuthRequest(name = name, email = email, password = password, language = lang))
                    vm.token = resp.token; vm.user = resp.user; vm.prefs.saveToken(resp.token)
                    onLoggedIn()
                }.onFailure { error = it.message?.let { m -> if (m.contains("HTTP 401") || m.contains("401")) "Invalid email or password." else m } ?: "Login failed. Please try again." }
                loading = false
            }
        }, loading = loading, enabled = email.isNotBlank() && password.isNotBlank() && (isLogin || name.isNotBlank()))

        Spacer(Modifier.height(16.dp))
        TextButton(onClick = { isLogin = !isLogin; error = null }) {
            Text(if (isLogin) "Don't have an account? Sign up" else "Already have an account? Login")
        }
        // Google login placeholder — wire with Firebase Auth / Google Identity; backend verifies token.
        // OutlinedButton(onClick = { /* launch Google sign-in; send idToken to backend */ }) { Text("Continue with Google") }
    }
}
