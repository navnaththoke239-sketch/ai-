# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class com.aistudio.data.** { *; }
-dontwarn org.conscrypt.**
