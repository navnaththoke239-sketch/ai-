import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { connectDB } from './config/database.js';
import { protect, adminOnly } from './middleware/auth.js';
import { apiLimiter } from './middleware/rateLimit.js';

import statusRoutes from './routes/status.js';
import authRoutes from './routes/auth.js';
import chatRoutes from './routes/chat.js';
import imageRoutes from './routes/image.js';
import videoRoutes from './routes/video.js';
import voiceRoutes from './routes/voice.js';
import musicRoutes from './routes/music.js';
import writerRoutes from './routes/writer.js';
import promptRoutes from './routes/prompt.js';
import projectRoutes from './routes/projects.js';
import adminRoutes from './routes/admin.js';

const app = express();
const PORT = process.env.PORT || 5000;

// ---- Security & parsing ----
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
const origins = (process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim());
app.use(cors({ origin: origins.length === 1 && origins[0] === '*' ? true : origins }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(apiLimiter);

// ---- Public routes ----
app.use('/api', statusRoutes);          // /api/status, /api/health
app.use('/api/auth', authRoutes);       // signup, login (no protect) — /me is protected below

// ---- Protected routes (every request authenticated) ----
app.use('/api/auth/me', protect);       // GET/PUT /api/auth/me
app.use('/api/chat', protect, chatRoutes);
app.use('/api/image', protect, imageRoutes);
app.use('/api/video', protect, videoRoutes);
app.use('/api/voice', protect, voiceRoutes);
app.use('/api/music', protect, musicRoutes);
app.use('/api/writer', protect, writerRoutes);
app.use('/api/prompt', protect, promptRoutes);
app.use('/api/projects', protect, projectRoutes);
app.use('/api/admin', protect, adminOnly, adminRoutes);

// Serve admin panel statically (built HTML in ../admin)
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use('/admin', express.static(path.join(__dirname, '..', 'admin')));

// ---- 404 + error handler ----
app.use((req, res) => res.status(404).json({ error: 'Not found.' }));
app.use((err, req, res, next) => {
  console.error('[server]', err);
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large.' });
  res.status(500).json({ error: 'Server is busy. Please try again later.' });
});

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`[server] AI Studio backend running on http://localhost:${PORT}`);
    console.log(`[server] Admin panel: http://localhost:${PORT}/admin`);
  });
});
