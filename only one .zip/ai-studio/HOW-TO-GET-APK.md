# AI Studio APK — ५ मिनिटांत तयार करा (कुठल्याही computer ची गरज नाही)

## Step 1: GitHub वर free account बनवा
1. https://github.com वर जा → Sign up → email ने account बनवा (फ्री)

## Step 2: नवीन Repository बनवा
1. GitHub वर login झाल्यावर वरच्या उजव्या कोपऱ्यात **+** → **New repository**
2. नाव द्या: `ai-studio`
3. **Public** ठेवा → **Create repository**

## Step 3: Project upload करा
1. माझा दिलेला `ai-studio.zip` extract करा
2. GitHub वर repository उघडा → **uploading an existing file** वर click करा
3. सर्व files/folders (`android`, `backend`, `admin`, `.github`, `SETUP.md`, `README.md`) drag & drop करा
4. **Commit changes** दाबा

## Step 4: Automatic build सुरू होईल!
1. Upload झाल्यावर repository वर **Actions** टॅब वर जा
2. तिथे "Build Android APK" चालू दिसेल (हिरवा ✓ येईपर्यंत थांबा — सुमारे ५-१० मिनिटे)
3. Build पूर्ण झाल्यावर त्या run वर click करा → खाली **Artifacts** मध्ये **AI-Studio-APK** दिसेल
4. त्यावर click करा → APK download होईल!

## Step 5: Phone वर install करा
1. Download झालेला `.zip` extract करा → आते `app-debug.apk` मिळेल
2. तो APK file WhatsApp/email ने तुमच्या phone वर पाठवा
3. Phone वर open करा → **Install** (settings मध्ये "unknown sources" allow करावा लागेल)

## महत्त्वाची गोष्ट 🔑
App install झाला की तो उघडेल, पण real AI चालण्यासाठी backend लागतो. Backend setup साठी `SETUP.md` वाचा — Render.com वर फ्री deploy करता येतो.
