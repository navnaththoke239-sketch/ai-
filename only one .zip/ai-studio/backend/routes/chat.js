import { Router } from 'express';
import { body } from 'express-validator';
import Chat from '../models/Chat.js';
import Generation from '../models/Generation.js';
import Script from '../models/Script.js';
import ProviderFactory from '../providers/ProviderFactory.js';
import { ProviderNotConfiguredError } from '../providers/BaseProvider.js';
import { estimateCost, deductCredits, refundCredits } from '../utils/credits.js';

const router = Router();

// GET /api/chat  -> list user's conversations (history)
router.get('/', async (req, res) => {
  const chats = await Chat.find({ userId: req.user._id }).sort({ updatedAt: -1 }).select('title updatedAt createdAt messageCount');
  const withCount = chats.map(c => ({ id: c._id, title: c.title, updatedAt: c.updatedAt, createdAt: c.createdAt, messageCount: c.messages?.length || 0 }));
  res.json({ chats: withCount, credits: req.user.credits });
});

// GET /api/chat/:id -> full conversation
router.get('/:id', async (req, res) => {
  const chat = await Chat.findOne({ _id: req.params.id, userId: req.user._id });
  if (!chat) return res.status(404).json({ error: 'Conversation not found.' });
  res.json({ chat, credits: req.user.credits });
});

// POST /api/chat -> send a message, get AI reply (streaming-free simple version)
// Body: { chatId?, messages: [{role,content}], language, projectId? }
router.post('/', [body('messages').isArray({ min: 1 })], async (req, res) => {
  try {
    const { messages, language, projectId, chatId } = req.body;
    if (!messages || !messages.length) return res.status(400).json({ error: 'Please enter a message.' });

    const cost = estimateCost('chat');
    let remaining;
    try { remaining = await deductCredits(req.user._id, cost); }
    catch (e) { return res.status(402).json({ error: e.message || 'Your credits are insufficient.' }); }

    const provider = ProviderFactory.getChatProvider();
    // Inject system instruction for language + helpfulness
    const langName = { en: 'English', hi: 'Hindi', mr: 'Marathi' }[language] || 'English';
    const systemMsg = {
      role: 'system',
      content: `You are a helpful AI assistant inside AI Studio. Reply in ${langName}. You can write stories, captions, scripts, ideas and explanations. Be concise and friendly.`,
    };
    const fullMessages = [systemMsg, ...messages.slice(-20)]; // keep context window sane

    let reply;
    try {
      reply = await provider.chat(fullMessages, { language });
    } catch (err) {
      await refundCredits(req.user._id, cost);
      if (err instanceof ProviderNotConfiguredError) return res.status(503).json({ error: err.message });
      console.error('[chat]', err);
      return res.status(502).json({ error: 'Generation failed. Please try again.' });
    }

    // Save / update conversation
    let chat;
    if (chatId) {
      chat = await Chat.findOne({ _id: chatId, userId: req.user._id });
    }
    if (!chat) {
      chat = await Chat.create({
        userId: req.user._id,
        title: (messages[0]?.content || 'New Chat').slice(0, 60),
        projectId: projectId || null,
        messages: [],
      });
    }
    const lastUser = messages[messages.length - 1];
    chat.messages.push({ role: 'user', content: lastUser.content, language: language || 'en' });
    chat.messages.push({ role: 'assistant', content: reply, language: language || 'en' });
    chat.updatedAt = new Date();
    if (projectId && !chat.projectId) chat.projectId = projectId;
    await chat.save();

    res.json({ chatId: chat._id, reply, credits: remaining, creditsUsed: cost });
  } catch (err) {
    console.error('[chat]', err);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

// DELETE /api/chat/:id
router.delete('/:id', async (req, res) => {
  await Chat.deleteOne({ _id: req.params.id, userId: req.user._id });
  res.json({ ok: true });
});

// GET /api/history -> all generations + scripts across types (for History tab)
router.get('/history/all', async (req, res) => {
  const [gens, scripts] = await Promise.all([
    Generation.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(100),
    Script.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(100),
  ]);
  res.json({ generations: gens, scripts, credits: req.user.credits });
});

export default router;
